#
# TABLE STRUCTURE FOR: article_has_attachments
#

DROP TABLE IF EXISTS article_has_attachments;

CREATE TABLE `article_has_attachments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `article_id` bigint(20) DEFAULT NULL,
  `filename` varchar(250) DEFAULT NULL,
  `savename` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO article_has_attachments (`id`, `article_id`, `filename`, `savename`) VALUES ('1', '3', 'Esboço_Ensaio_de_Comissionamento.docx', 'ea1c26644c5694f958853a97ca750169.docx');


#
# TABLE STRUCTURE FOR: clients
#

DROP TABLE IF EXISTS clients;

CREATE TABLE `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(140) DEFAULT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `email` varchar(180) DEFAULT NULL,
  `phone` varchar(25) DEFAULT NULL,
  `mobile` varchar(25) DEFAULT NULL,
  `address` varchar(150) DEFAULT NULL,
  `zipcode` varchar(30) DEFAULT NULL,
  `userpic` varchar(150) DEFAULT 'no-pic.png',
  `city` varchar(45) DEFAULT NULL,
  `hashed_password` varchar(255) DEFAULT NULL,
  `inactive` tinyint(4) DEFAULT '0',
  `access` varchar(150) DEFAULT '0',
  `last_active` varchar(50) DEFAULT NULL,
  `last_login` varchar(50) DEFAULT NULL,
  `twitter` varchar(255) DEFAULT NULL,
  `skype` varchar(255) DEFAULT NULL,
  `linkedin` varchar(255) DEFAULT NULL,
  `facebook` varchar(255) DEFAULT NULL,
  `instagram` varchar(255) DEFAULT NULL,
  `googleplus` varchar(255) DEFAULT NULL,
  `youtube` varchar(255) DEFAULT NULL,
  `pinterest` varchar(255) DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `signature` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`, `twitter`, `skype`, `linkedin`, `facebook`, `instagram`, `googleplus`, `youtube`, `pinterest`, `token`, `language`, `signature`) VALUES ('1', '1', 'Ingred', 'Preis', 'zenit.cliente@ownergy.com.br', '(31)3333-3333', '(31)9999-9999', 'Rua do Google, 1000', '31100-100', '9cfeb96fdc6c651728216a081f5419a4.jpg', 'Belo Horizonte', '7427514b7533525f4d323a727a6b402443254b3c3922365b6a2f522c585a356a2dc1a3da71ddd3dafb6979085be543d5cfb10c585cda2fddc85b6d2388a6690f', '0', '103,101,106', '1544097700', '1544097645', '', '', '', '', '', '', '', '', NULL, NULL, NULL);
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`, `twitter`, `skype`, `linkedin`, `facebook`, `instagram`, `googleplus`, `youtube`, `pinterest`, `token`, `language`, `signature`) VALUES ('2', '2', 'Amanda', 'Freitas', 'zenit.cliente2@ownergy.com.br', '(31)34445-5554', '(31)99555-5554', 'Rua da Apple, 2000', '31200-200', '7247b36973eaf4a708f508b9465cd478.jpg', 'Belo Horizonte', '592d737079226775755e363f5d5b4c3b506f6d41292c6564757b636e6c3c77592f7c210d78f5a5ff1fd5a2ee8a8c6bb72f2edaada2a186502ab124ceaa92e54e', '0', '103,101,106', '0', '1543517114', '', '', '', '', '', '', '', '', NULL, NULL, NULL);
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`, `twitter`, `skype`, `linkedin`, `facebook`, `instagram`, `googleplus`, `youtube`, `pinterest`, `token`, `language`, `signature`) VALUES ('3', '3', 'Matheus', 'Castro', 'zenit.cliente3@ownergy.com.br', '(31)3445-4541', '(31)99845-3344', 'Rua da Samsung, 3000', '31300-300', 'e11457d724e16e3b8dde28c7e3209d96.jpg', 'Belo Horizonte', '66413f537b3a56263347505f515d3a633f6629663b41276c5c28357334273071d098d22e5b77adf87f19f5773a8d35c8f339d10b4528607a71f0d2beb1c77586', '0', '103,101,106', '1544184112', '1544183182', '', '', '', '', '', '', '', '', NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: companies
#

DROP TABLE IF EXISTS companies;

CREATE TABLE `companies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` int(11) NOT NULL,
  `name` varchar(140) DEFAULT NULL,
  `client_id` varchar(140) DEFAULT NULL,
  `phone` varchar(25) DEFAULT NULL,
  `mobile` varchar(25) DEFAULT NULL,
  `address` varchar(150) DEFAULT NULL,
  `zipcode` varchar(30) NOT NULL,
  `city` varchar(45) DEFAULT NULL,
  `inactive` tinyint(4) DEFAULT '0',
  `website` varchar(250) DEFAULT NULL,
  `country` varchar(250) DEFAULT NULL,
  `vat` varchar(250) DEFAULT NULL,
  `note` longtext,
  `province` varchar(255) DEFAULT NULL,
  `twitter` varchar(255) NOT NULL,
  `skype` varchar(255) NOT NULL,
  `linkedin` varchar(255) NOT NULL,
  `facebook` varchar(255) NOT NULL,
  `instagram` varchar(255) NOT NULL,
  `googleplus` varchar(255) NOT NULL,
  `youtube` varchar(255) NOT NULL,
  `pinterest` varchar(255) NOT NULL,
  `terms` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`, `twitter`, `skype`, `linkedin`, `facebook`, `instagram`, `googleplus`, `youtube`, `pinterest`, `terms`) VALUES ('1', '41001', 'Google Inc', '1', '(31)3333-3333', '(31)99999-9999', 'Rua do Google, 1000', '31100-100', 'Belo Horizonte', '0', 'www.google.com.br', 'Brasil', '', NULL, 'MG', '', '', '', '', '', '', '', '', '');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`, `twitter`, `skype`, `linkedin`, `facebook`, `instagram`, `googleplus`, `youtube`, `pinterest`, `terms`) VALUES ('2', '41002', 'Apple Inc', '2', '(31)3444-4444', '(31)99999-4444', 'Rua da Apple, 2000', '31200-200', 'Belo Horizonte', '0', 'apple.com.br', 'Brasil', '', NULL, 'MG', '', '', '', '', '', '', '', '', '');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`, `twitter`, `skype`, `linkedin`, `facebook`, `instagram`, `googleplus`, `youtube`, `pinterest`, `terms`) VALUES ('3', '41003', 'Samsung Electronics Co.', '3', '(31)3443-4356', '(31)99345-3345', 'Rua da Samsung, 3000', '31300-300', 'Belo Horizonte', '0', 'samsung.com.br', 'Brasil', '', '&lt;p&gt;Notas compartilhadas? Teste&lt;/p&gt;', 'MG', '', '', '', '', '', '', '', '', '');


#
# TABLE STRUCTURE FOR: company_has_admins
#

DROP TABLE IF EXISTS company_has_admins;

CREATE TABLE `company_has_admins` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `company_id` int(10) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  `access` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO company_has_admins (`id`, `company_id`, `user_id`, `access`) VALUES ('1', '1', '1', NULL);
INSERT INTO company_has_admins (`id`, `company_id`, `user_id`, `access`) VALUES ('2', '2', '1', NULL);
INSERT INTO company_has_admins (`id`, `company_id`, `user_id`, `access`) VALUES ('3', '3', '1', NULL);


#
# TABLE STRUCTURE FOR: core
#

DROP TABLE IF EXISTS core;

CREATE TABLE `core` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` char(10) NOT NULL DEFAULT '0',
  `domain` varchar(65) DEFAULT NULL,
  `email` varchar(80) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `tax` varchar(5) DEFAULT NULL,
  `second_tax` varchar(5) DEFAULT NULL,
  `currency` varchar(20) DEFAULT NULL,
  `autobackup` int(11) DEFAULT NULL,
  `cronjob` int(11) DEFAULT NULL,
  `last_cronjob` int(11) DEFAULT NULL,
  `last_autobackup` int(11) DEFAULT NULL,
  `invoice_terms` mediumtext,
  `company_reference` int(6) DEFAULT NULL,
  `project_reference` int(6) DEFAULT NULL,
  `invoice_reference` int(6) DEFAULT NULL,
  `subscription_reference` int(6) DEFAULT NULL,
  `ticket_reference` int(10) DEFAULT NULL,
  `date_format` varchar(20) DEFAULT NULL,
  `date_time_format` varchar(20) DEFAULT NULL,
  `invoice_mail_subject` varchar(150) DEFAULT NULL,
  `pw_reset_mail_subject` varchar(150) DEFAULT NULL,
  `pw_reset_link_mail_subject` varchar(150) DEFAULT NULL,
  `credentials_mail_subject` varchar(150) DEFAULT NULL,
  `notification_mail_subject` varchar(150) DEFAULT NULL,
  `language` varchar(150) DEFAULT NULL,
  `invoice_address` varchar(200) DEFAULT NULL,
  `invoice_city` varchar(200) DEFAULT NULL,
  `invoice_contact` varchar(200) DEFAULT NULL,
  `invoice_tel` varchar(50) DEFAULT NULL,
  `subscription_mail_subject` varchar(250) DEFAULT NULL,
  `logo` varchar(150) DEFAULT NULL,
  `template` varchar(200) DEFAULT 'default',
  `paypal` varchar(5) DEFAULT '1',
  `paypal_currency` varchar(200) DEFAULT 'EUR',
  `paypal_account` varchar(200) DEFAULT 'luxsys@luxsys-apps.com',
  `invoice_logo` varchar(150) DEFAULT 'assets/blackline/img/invoice_logo.png',
  `pc` varchar(150) DEFAULT NULL,
  `vat` varchar(150) DEFAULT NULL,
  `ticket_email` varchar(250) DEFAULT NULL,
  `ticket_default_owner` int(10) DEFAULT '1',
  `ticket_default_queue` int(10) DEFAULT '1',
  `ticket_default_type` int(10) DEFAULT '1',
  `ticket_default_status` varchar(200) DEFAULT 'new',
  `ticket_config_host` varchar(250) DEFAULT NULL,
  `ticket_config_login` varchar(250) DEFAULT NULL,
  `ticket_config_pass` varchar(250) DEFAULT NULL,
  `ticket_config_port` varchar(250) DEFAULT NULL,
  `ticket_config_ssl` varchar(250) DEFAULT NULL,
  `ticket_config_email` varchar(250) DEFAULT NULL,
  `ticket_config_flags` varchar(250) DEFAULT '/notls',
  `ticket_config_search` varchar(250) DEFAULT 'UNSEEN',
  `ticket_config_timestamp` int(11) DEFAULT NULL,
  `ticket_config_mailbox` varchar(250) DEFAULT NULL,
  `ticket_config_delete` int(11) DEFAULT NULL,
  `ticket_config_active` int(11) DEFAULT NULL,
  `ticket_config_imap` int(11) DEFAULT '1',
  `stripe` int(11) DEFAULT '0',
  `stripe_key` varchar(250) DEFAULT NULL,
  `stripe_p_key` varchar(255) DEFAULT NULL,
  `bank_transfer` int(11) DEFAULT NULL,
  `bank_transfer_text` longtext,
  `stripe_currency` varchar(255) NOT NULL DEFAULT 'USD',
  `estimate_terms` longtext,
  `estimate_prefix` varchar(255) NOT NULL DEFAULT 'EST',
  `estimate_pdf_template` varchar(255) NOT NULL DEFAULT 'templates/estimate/default',
  `invoice_pdf_template` varchar(255) NOT NULL DEFAULT 'invoices/preview',
  `estimate_mail_subject` varchar(255) NOT NULL DEFAULT 'New Estimate #{estimate_id}',
  `money_currency_position` int(5) NOT NULL DEFAULT '1',
  `money_format` int(5) NOT NULL DEFAULT '1',
  `pdf_font` varchar(255) NOT NULL DEFAULT 'NotoSans',
  `pdf_path` int(10) NOT NULL DEFAULT '1',
  `registration` int(10) NOT NULL DEFAULT '0',
  `authorize_api_login_id` varchar(255) DEFAULT NULL,
  `authorize_api_transaction_key` varchar(255) DEFAULT NULL,
  `authorize_net` int(20) DEFAULT '0',
  `authorize_currency` varchar(30) DEFAULT NULL,
  `invoice_prefix` varchar(255) DEFAULT NULL,
  `company_prefix` varchar(255) DEFAULT NULL,
  `quotation_prefix` varchar(255) DEFAULT NULL,
  `project_prefix` varchar(255) DEFAULT NULL,
  `subscription_prefix` varchar(255) DEFAULT NULL,
  `calendar_google_api_key` varchar(255) DEFAULT NULL,
  `calendar_google_event_address` varchar(255) DEFAULT NULL,
  `default_client_modules` varchar(255) DEFAULT NULL,
  `estimate_reference` int(10) DEFAULT '0',
  `login_background` varchar(255) DEFAULT 'blur.jpg',
  `custom_colors` int(1) DEFAULT '1',
  `top_bar_background` varchar(60) DEFAULT '#FFFFFF',
  `top_bar_color` varchar(60) DEFAULT '#333333',
  `body_background` varchar(60) DEFAULT '#e3e6ed',
  `menu_background` varchar(60) DEFAULT '#173240',
  `menu_color` varchar(60) DEFAULT '#FFFFFF',
  `primary_color` varchar(60) DEFAULT '#356cc9',
  `twocheckout_seller_id` varchar(250) DEFAULT NULL,
  `twocheckout_publishable_key` varchar(250) DEFAULT NULL,
  `twocheckout_private_key` varchar(250) DEFAULT NULL,
  `twocheckout` int(11) DEFAULT '0',
  `twocheckout_currency` varchar(250) DEFAULT NULL,
  `login_logo` varchar(255) DEFAULT NULL,
  `login_style` varchar(255) DEFAULT 'left',
  `reference_lenght` int(20) DEFAULT NULL,
  `stripe_ideal` int(1) DEFAULT NULL,
  `zip_position` varchar(60) DEFAULT 'left',
  `timezone` varchar(255) DEFAULT NULL,
  `notifications` int(1) unsigned DEFAULT '0',
  `last_notification` varchar(100) DEFAULT NULL,
  `receipt_mail_subject` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO core (`id`, `version`, `domain`, `email`, `company`, `tax`, `second_tax`, `currency`, `autobackup`, `cronjob`, `last_cronjob`, `last_autobackup`, `invoice_terms`, `company_reference`, `project_reference`, `invoice_reference`, `subscription_reference`, `ticket_reference`, `date_format`, `date_time_format`, `invoice_mail_subject`, `pw_reset_mail_subject`, `pw_reset_link_mail_subject`, `credentials_mail_subject`, `notification_mail_subject`, `language`, `invoice_address`, `invoice_city`, `invoice_contact`, `invoice_tel`, `subscription_mail_subject`, `logo`, `template`, `paypal`, `paypal_currency`, `paypal_account`, `invoice_logo`, `pc`, `vat`, `ticket_email`, `ticket_default_owner`, `ticket_default_queue`, `ticket_default_type`, `ticket_default_status`, `ticket_config_host`, `ticket_config_login`, `ticket_config_pass`, `ticket_config_port`, `ticket_config_ssl`, `ticket_config_email`, `ticket_config_flags`, `ticket_config_search`, `ticket_config_timestamp`, `ticket_config_mailbox`, `ticket_config_delete`, `ticket_config_active`, `ticket_config_imap`, `stripe`, `stripe_key`, `stripe_p_key`, `bank_transfer`, `bank_transfer_text`, `stripe_currency`, `estimate_terms`, `estimate_prefix`, `estimate_pdf_template`, `invoice_pdf_template`, `estimate_mail_subject`, `money_currency_position`, `money_format`, `pdf_font`, `pdf_path`, `registration`, `authorize_api_login_id`, `authorize_api_transaction_key`, `authorize_net`, `authorize_currency`, `invoice_prefix`, `company_prefix`, `quotation_prefix`, `project_prefix`, `subscription_prefix`, `calendar_google_api_key`, `calendar_google_event_address`, `default_client_modules`, `estimate_reference`, `login_background`, `custom_colors`, `top_bar_background`, `top_bar_color`, `body_background`, `menu_background`, `menu_color`, `primary_color`, `twocheckout_seller_id`, `twocheckout_publishable_key`, `twocheckout_private_key`, `twocheckout`, `twocheckout_currency`, `login_logo`, `login_style`, `reference_lenght`, `stripe_ideal`, `zip_position`, `timezone`, `notifications`, `last_notification`, `receipt_mail_subject`) VALUES ('1', '3.3.0', 'http://localhost/ownergy/zenit/', 'local@localhost', 'Ownergy Solar', '0', '', 'BRL', '1', '1', '0', '0', '', '41004', '51007', '31001', '61001', '10004', 'd/m/Y', 'H:i', 'New Invoice', 'Password Reset', 'Password Reset', 'Login Details', 'Notification', 'portuguese', 'Rua Araguari, 1156, 1301, Santo Agostinho', 'Belo Horizonte', '(31) 3654-0098', '(31) 3654-0098', 'New Subscription', 'files/media/zenit_logo.png', 'blueline', '0', 'BRL', '', 'files/media/ownergy_logo.png', 'nulled', '', NULL, '1', '1', '1', 'new', NULL, NULL, NULL, NULL, NULL, NULL, '/notls', 'UNSEEN', NULL, NULL, NULL, NULL, '1', '0', '', '', NULL, NULL, 'BRL', '', 'ORC', 'templates/estimate/default', 'invoices/preview', 'New Estimate #{estimate_id}', '1', '2', 'NotoSans', '1', '0', NULL, NULL, '0', NULL, 'FAT', 'CLI', 'COT', 'PRJ', 'SUB', '1022232899186-1k9itl671m7t18t81b6dj7k02m10bms3.apps.googleusercontent.com', '', NULL, '20000', 'Blur-2.jpg', '1', '#355ab9', '#ffffff', '#e3e6ed', '#2a3f5c', '#ffffff', '#355ab9', NULL, NULL, NULL, '0', NULL, NULL, 'center', NULL, NULL, 'left', 'America/Sao_Paulo', '0', NULL, NULL);


#
# TABLE STRUCTURE FOR: custom_quotation_requests
#

DROP TABLE IF EXISTS custom_quotation_requests;

CREATE TABLE `custom_quotation_requests` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `form` longtext,
  `custom_quotation_id` int(11) DEFAULT NULL,
  `date` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: custom_quotations
#

DROP TABLE IF EXISTS custom_quotations;

CREATE TABLE `custom_quotations` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `formcontent` longtext,
  `inactive` int(250) DEFAULT '0',
  `user_id` int(11) DEFAULT NULL,
  `created` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: events
#

DROP TABLE IF EXISTS events;

CREATE TABLE `events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `allday` varchar(30) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `classname` varchar(255) DEFAULT NULL,
  `start` varchar(255) DEFAULT NULL,
  `end` varchar(255) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT '0',
  `access` varchar(255) DEFAULT NULL,
  `reminder` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO events (`id`, `title`, `description`, `allday`, `url`, `classname`, `start`, `end`, `user_id`, `access`, `reminder`) VALUES ('1', 'Criar o Canvas para UFV001', 'Reunir com os colaboradores para criarmos o Canvas do projeto', NULL, NULL, 'bgColor19', '2018-11-25 12:00', '2018-11-25 12:00', '1', NULL, NULL);
INSERT INTO events (`id`, `title`, `description`, `allday`, `url`, `classname`, `start`, `end`, `user_id`, `access`, `reminder`) VALUES ('2', 'Apresentação de projeto', 'Apresentar o sistema Zenit para equipe', NULL, NULL, 'bgColor12', '2018-12-05 12:00', '2018-12-05 12:00', '1', NULL, NULL);


#
# TABLE STRUCTURE FOR: expenses
#

DROP TABLE IF EXISTS expenses;

CREATE TABLE `expenses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `currency` varchar(255) DEFAULT NULL,
  `value` float(20,2) DEFAULT '0.00',
  `vat` varchar(255) DEFAULT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `project_id` bigint(20) DEFAULT '0',
  `rebill` int(20) DEFAULT '0',
  `invoice_id` bigint(20) DEFAULT '0',
  `attachment` varchar(255) DEFAULT NULL,
  `attachment_description` varchar(255) DEFAULT NULL,
  `recurring` varchar(255) DEFAULT NULL,
  `recurring_until` varchar(255) DEFAULT NULL,
  `user_id` int(20) DEFAULT '0',
  `expense_id` int(20) DEFAULT '0',
  `next_payment` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: invoice_has_items
#

DROP TABLE IF EXISTS invoice_has_items;

CREATE TABLE `invoice_has_items` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) DEFAULT '0',
  `item_id` int(11) DEFAULT '0',
  `amount` char(11) DEFAULT NULL,
  `description` mediumtext,
  `value` float DEFAULT '0',
  `name` varchar(250) DEFAULT NULL,
  `type` varchar(250) DEFAULT NULL,
  `task_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: invoice_has_payments
#

DROP TABLE IF EXISTS invoice_has_payments;

CREATE TABLE `invoice_has_payments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `invoice_id` bigint(20) DEFAULT '0',
  `reference` varchar(255) DEFAULT NULL,
  `amount` float DEFAULT '0',
  `date` varchar(20) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `notes` text,
  `user_id` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: invoices
#

DROP TABLE IF EXISTS invoices;

CREATE TABLE `invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sum` float NOT NULL DEFAULT '0',
  `estimate_sent` varchar(255) NOT NULL DEFAULT '0',
  `estimate_status` varchar(255) NOT NULL DEFAULT '0',
  `project_id` int(11) DEFAULT '0',
  `reference` int(11) DEFAULT '0',
  `company_id` int(11) DEFAULT '0',
  `status` varchar(50) DEFAULT NULL,
  `currency` varchar(20) DEFAULT NULL,
  `issue_date` varchar(20) DEFAULT NULL,
  `due_date` varchar(20) DEFAULT NULL,
  `sent_date` varchar(20) DEFAULT NULL,
  `paid_date` varchar(20) DEFAULT NULL,
  `terms` mediumtext,
  `discount` varchar(50) DEFAULT NULL,
  `subscription_id` varchar(50) DEFAULT NULL,
  `tax` varchar(255) DEFAULT NULL,
  `second_tax` varchar(5) DEFAULT NULL,
  `estimate` int(11) DEFAULT '0',
  `estimate_accepted_date` varchar(255) DEFAULT NULL,
  `paid` float DEFAULT '0',
  `outstanding` float DEFAULT NULL,
  `estimate_reference` int(10) DEFAULT '0',
  `po_number` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: items
#

DROP TABLE IF EXISTS items;

CREATE TABLE `items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `value` float DEFAULT '0',
  `type` varchar(45) DEFAULT NULL,
  `inactive` tinyint(4) DEFAULT '0',
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: lead_has_comments
#

DROP TABLE IF EXISTS lead_has_comments;

CREATE TABLE `lead_has_comments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `attachment` varchar(250) DEFAULT NULL,
  `attachment_link` varchar(250) DEFAULT NULL,
  `datetime` varchar(250) DEFAULT NULL,
  `message` text,
  `user_id` bigint(20) DEFAULT '0',
  `lead_id` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: lead_status
#

DROP TABLE IF EXISTS lead_status;

CREATE TABLE `lead_status` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `description` text,
  `order` float DEFAULT '0',
  `offset` bigint(200) DEFAULT '0',
  `limit` bigint(200) DEFAULT '50',
  `color` varchar(100) DEFAULT '#5071ab',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: leads
#

DROP TABLE IF EXISTS leads;

CREATE TABLE `leads` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status_id` bigint(20) DEFAULT '0',
  `source` varchar(250) DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `position` varchar(250) DEFAULT NULL,
  `address` varchar(250) DEFAULT NULL,
  `city` varchar(250) DEFAULT NULL,
  `state` varchar(250) DEFAULT NULL,
  `country` varchar(250) DEFAULT NULL,
  `zipcode` varchar(250) DEFAULT NULL,
  `language` varchar(250) DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `website` varchar(250) DEFAULT NULL,
  `phone` varchar(250) DEFAULT NULL,
  `mobile` varchar(250) DEFAULT NULL,
  `company` varchar(250) DEFAULT NULL,
  `tags` varchar(250) DEFAULT NULL,
  `description` text,
  `first_contact` varchar(250) DEFAULT NULL,
  `last_contact` varchar(250) DEFAULT NULL,
  `valid_until` varchar(250) DEFAULT NULL,
  `created` varchar(20) DEFAULT NULL,
  `modified` varchar(20) DEFAULT NULL,
  `private` varchar(20) DEFAULT '0',
  `custom` varchar(255) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT '0',
  `icon` varchar(255) DEFAULT NULL,
  `order` float DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: messages
#

DROP TABLE IF EXISTS messages;

CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT '0',
  `media_id` int(11) DEFAULT '0',
  `from` varchar(120) DEFAULT NULL,
  `text` text,
  `datetime` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO messages (`id`, `project_id`, `media_id`, `from`, `text`, `datetime`) VALUES ('1', '3', '2', 'Thiago Pires', '<p>Teste de <b><font color=\"#ff0000\">comentário</font></b> em arquivo de mídia</p>', '2018-12-06 11:38');


#
# TABLE STRUCTURE FOR: migrations
#

DROP TABLE IF EXISTS migrations;

CREATE TABLE `migrations` (
  `version` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO migrations (`version`) VALUES ('41');


#
# TABLE STRUCTURE FOR: modules
#

DROP TABLE IF EXISTS modules;

CREATE TABLE `modules` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `link` varchar(250) DEFAULT NULL,
  `type` varchar(250) DEFAULT NULL,
  `icon` varchar(150) DEFAULT NULL,
  `sort` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8;

INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('1', 'Dashboard', 'dashboard', 'main', 'icon dripicons-meter', '1');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('2', 'Messages', 'messages', 'main', 'icon dripicons-message', '2');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('3', 'Projects', 'projects', 'main', 'icon dripicons-rocket', '3');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('4', 'Clients', 'clients', 'main', 'icon dripicons-user', '4');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('5', 'Invoices', 'invoices', 'main', 'icon dripicons-document', '5');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('6', 'Items', 'items', 'main', 'icon dripicons-shopping-bag', '7');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('7', 'Quotations', 'quotations', 'main', 'icon dripicons-blog', '8');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('8', 'Subscriptions', 'subscriptions', 'main', 'icon dripicons-retweet', '6');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('9', 'Settings', 'settings', 'main', 'icon dripicons-toggles', '20');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('10', 'QuickAccess', 'quickaccess', 'widget', '', '50');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('11', 'User Online', 'useronline', 'widget', '', '51');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('12', 'Estimates', 'estimates', 'main', 'icon dripicons-document-edit', '5');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('13', 'Expenses', 'expenses', 'main', 'icon dripicons-cart', '5');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('20', 'Calendar', 'calendar', 'main', 'icon dripicons-calendar', '8');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('33', 'Reports', 'reports', 'main', 'icon dripicons-graph-pie', '8');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('101', 'Projects', 'cprojects', 'client', 'icon dripicons-rocket', '2');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('102', 'Invoices', 'cinvoices', 'client', 'icon dripicons-document', '3');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('103', 'Messages', 'cmessages', 'client', 'icon dripicons-message', '1');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('104', 'Subscriptions', 'csubscriptions', 'client', 'icon dripicons-retweet', '4');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('105', 'Tickets', 'tickets', 'main', 'icon dripicons-ticket', '8');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('106', 'Tickets', 'ctickets', 'client', 'icon dripicons-ticket', '4');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('107', 'Estimates', 'cestimates', 'client', 'icon dripicons-document-edit', '3');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('108', 'Leads', 'leads', 'main', 'icon dripicons-phone', '4');


#
# TABLE STRUCTURE FOR: privatemessages
#

DROP TABLE IF EXISTS privatemessages;

CREATE TABLE `privatemessages` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(150) DEFAULT NULL,
  `sender` varchar(250) DEFAULT NULL,
  `recipient` varchar(250) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `message` text,
  `time` varchar(100) DEFAULT NULL,
  `conversation` varchar(32) DEFAULT NULL,
  `deleted` int(11) DEFAULT '0',
  `attachment` varchar(255) DEFAULT NULL,
  `attachment_link` varchar(255) DEFAULT NULL,
  `receiver_delete` int(11) DEFAULT '0',
  `marked` int(1) DEFAULT '0',
  `read` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('1', 'Replied', 'c1', 'u1', 'Gostei do projeto', '<p>Foi muito bom fazer este projeto com vocês, vou indicá-los para outras pessoas.</p>', '2018-11-26 11:32', '8000e2c388cbc781bb80e4b14a36e182', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('2', 'Replied', 'u1', 'c1', 'Gostei do projeto', '<p>Que bom que gostou, da <u>próxima</u> o Alan vai executar tudo mais rápido!</p>', '2018-11-26 11:33', '8000e2c388cbc781bb80e4b14a36e182', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('3', 'Replied', 'u1', 'c1', 'Gostei do projeto', '<p>Mensagem 3</p>', '2018-11-26 14:15', '8000e2c388cbc781bb80e4b14a36e182', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('4', 'Replied', 'u1', 'c1', 'Gostei do projeto', '<p>Mensagem 4</p>', '2018-11-26 14:28', '8000e2c388cbc781bb80e4b14a36e182', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('5', 'Read', 'c1', 'u1', 'Gostei do projeto', '<p>Mensagem 5</p>', '2018-11-26 14:34', '8000e2c388cbc781bb80e4b14a36e182', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('6', 'Replied', 'c3', 'u1', 'Mensagem sobre o projeto', '<p>Teste de mensagem no projeto</p>', '2018-11-27 16:52', 'c2854f4abda0e6a20a67881d51608fb5', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('7', 'Replied', 'u1', 'c3', 'Mensagem sobre o projeto', '<p>Beleza</p>', '2018-11-29 16:40', 'c2854f4abda0e6a20a67881d51608fb5', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('8', 'Replied', 'c3', 'u1', 'Mensagem sobre o projeto', '<p><b><font color=\"#ff9c00\">certo</font></b></p>', '2018-11-29 16:40', 'c2854f4abda0e6a20a67881d51608fb5', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('9', 'Replied', 'u1', 'c3', 'Mensagem sobre o projeto', '<p><i><u>Mensagem</u></i> de <font color=\"#0000ff\">teste</font> de <span style=\"font-size: 18px;\"><b>envio</b></span> de <b>notificação</b></p>', '2018-12-05 11:00', 'c2854f4abda0e6a20a67881d51608fb5', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('10', 'Replied', 'u1', 'c3', 'Mensagem sobre o projeto', '<p>testeeee</p>', '2018-12-05 11:00', 'c2854f4abda0e6a20a67881d51608fb5', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('11', 'Replied', 'u1', 'c3', 'Mensagem sobre o projeto', '<p>teste de recebimento de notificação</p>', '2018-12-05 11:02', 'c2854f4abda0e6a20a67881d51608fb5', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('12', 'Replied', 'c3', 'u1', 'Mensagem sobre o projeto', '<p><b><i>Teste </i></b>de notificação para <span style=\"background-color: rgb(255, 156, 0);\"><font color=\"#00ff00\">Thiago</font></span></p>', '2018-12-05 11:52', 'c2854f4abda0e6a20a67881d51608fb5', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('13', 'Replied', 'u1', 'c3', 'Mensagem sobre o projeto', '<p><b><i><u>Teste</u></i></b> 1 2 3</p>', '2018-12-05 11:53', 'c2854f4abda0e6a20a67881d51608fb5', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('14', 'Replied', 'c3', 'u1', 'Mensagem sobre o projeto', '<p><b><u>Resposta</u></b> ao <font color=\"#0000ff\"><b>teste</b></font></p>', '2018-12-05 12:16', 'c2854f4abda0e6a20a67881d51608fb5', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('15', 'Replied', 'u1', 'c3', 'Mensagem sobre o projeto', '<p><b><i>Boa</i></b> tarde!</p>', '2018-12-05 13:21', 'c2854f4abda0e6a20a67881d51608fb5', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('16', 'Replied', 'u1', 'c3', 'Mensagem sobre o projeto', '<p><b>Tudo</b> bom?</p>', '2018-12-05 14:07', 'c2854f4abda0e6a20a67881d51608fb5', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('17', 'Replied', 'c3', 'u1', 'Mensagem sobre o projeto', '<p><font color=\"#0000ff\"><b>Resposta</b></font>!&nbsp;</p>', '2018-12-05 14:08', 'c2854f4abda0e6a20a67881d51608fb5', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('18', 'Read', 'u1', 'c3', 'Mensagem sobre o projeto', '<p><b><font color=\"#ff9c00\">1</font><font color=\"#ff0000\">2</font><font color=\"#9c00ff\">3</font><font color=\"#731842\">4</font><font color=\"#0000ff\">5</font></b></p>', '2018-12-05 14:10', 'c2854f4abda0e6a20a67881d51608fb5', '0', NULL, NULL, '0', '0', '0');


#
# TABLE STRUCTURE FOR: project_has_activities
#

DROP TABLE IF EXISTS project_has_activities;

CREATE TABLE `project_has_activities` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `project_id` bigint(20) DEFAULT '0',
  `user_id` bigint(20) DEFAULT '0',
  `client_id` bigint(20) DEFAULT '0',
  `datetime` varchar(250) DEFAULT NULL,
  `subject` varchar(250) DEFAULT NULL,
  `message` text,
  `type` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO project_has_activities (`id`, `project_id`, `user_id`, `client_id`, `datetime`, `subject`, `message`, `type`) VALUES ('4', '3', '1', '0', '1544123025', 'Título de segunda atividade', '<p>Vivamus aliquet blandit consectetur. Aenean luctus dui magna, in ornare purus placerat et. Nunc viverra tellus massa, quis imperdiet eros dapibus sed. Pellentesque eget arcu in quam dignissim fringilla ut quis arcu. Sed a est quam. In vestibulum felis nec eleifend blandit. Vivamus venenatis venenatis lectus, eget faucibus risus ullamcorper eu. Donec suscipit ultrices tincidunt. Vestibulum molestie gravida pharetra. Aliquam sit amet augue vel libero egestas viverra. Proin at lorem maximus nisl varius porttitor.<br></p>', 'comment');


#
# TABLE STRUCTURE FOR: project_has_files
#

DROP TABLE IF EXISTS project_has_files;

CREATE TABLE `project_has_files` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `project_id` int(10) DEFAULT '0',
  `user_id` int(10) DEFAULT '0',
  `client_id` int(10) DEFAULT '0',
  `type` varchar(80) DEFAULT NULL,
  `name` varchar(120) DEFAULT NULL,
  `filename` varchar(150) DEFAULT NULL,
  `description` text,
  `savename` varchar(200) DEFAULT NULL,
  `phase` varchar(100) DEFAULT NULL,
  `date` varchar(50) DEFAULT NULL,
  `download_counter` int(10) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO project_has_files (`id`, `project_id`, `user_id`, `client_id`, `type`, `name`, `filename`, `description`, `savename`, `phase`, `date`, `download_counter`) VALUES ('1', '1', '1', '0', 'application/pdf', 'Comprovante de pagamento', 'Cupom.pdf', 'Boleto gerado para pagamento da primeira parcela', '0ff6e532c8089ca6e257b9b30baee1bf.pdf', 'Planejamento', '2018-11-28 15:41', '0');
INSERT INTO project_has_files (`id`, `project_id`, `user_id`, `client_id`, `type`, `name`, `filename`, `description`, `savename`, `phase`, `date`, `download_counter`) VALUES ('2', '3', '1', '0', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'Planilha TAP', '20181113_-_TAP_-_Andreu_Jesus_Conceicao_de_Oliveira_-_ME.xlsx', 'Planilha de proposta de projeto', '9fa285e381b5f45b085246026b2fa932.xlsx', 'Planejamento', '2018-12-04 17:48', '0');


#
# TABLE STRUCTURE FOR: project_has_invoices
#

DROP TABLE IF EXISTS project_has_invoices;

CREATE TABLE `project_has_invoices` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `project_id` bigint(20) NOT NULL,
  `invoice_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: project_has_milestones
#

DROP TABLE IF EXISTS project_has_milestones;

CREATE TABLE `project_has_milestones` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `description` longtext,
  `due_date` varchar(255) DEFAULT NULL,
  `orderindex` int(11) DEFAULT '0',
  `start_date` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO project_has_milestones (`id`, `project_id`, `name`, `description`, `due_date`, `orderindex`, `start_date`) VALUES ('1', '1', 'Planejamento', '', '', '0', '');
INSERT INTO project_has_milestones (`id`, `project_id`, `name`, `description`, `due_date`, `orderindex`, `start_date`) VALUES ('2', '3', 'Pacote de Trabalho AAA', '', '2018-12-10', '0', '2018-11-29');
INSERT INTO project_has_milestones (`id`, `project_id`, `name`, `description`, `due_date`, `orderindex`, `start_date`) VALUES ('3', '3', 'Pacote de Trabalho BBB', '', '2018-12-15', '0', '2018-11-30');
INSERT INTO project_has_milestones (`id`, `project_id`, `name`, `description`, `due_date`, `orderindex`, `start_date`) VALUES ('4', '3', 'Pacote de Trabalho CCC', '', '2018-12-25', '0', '2018-12-15');


#
# TABLE STRUCTURE FOR: project_has_tasks
#

DROP TABLE IF EXISTS project_has_tasks;

CREATE TABLE `project_has_tasks` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `project_id` int(10) DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `public` int(10) DEFAULT NULL,
  `datetime` int(11) DEFAULT NULL,
  `due_date` varchar(250) DEFAULT NULL,
  `description` text,
  `start_date` varchar(250) DEFAULT NULL,
  `value` float DEFAULT '0',
  `priority` smallint(6) DEFAULT '0',
  `time` int(11) DEFAULT NULL,
  `client_id` int(30) DEFAULT '0',
  `created_by_client` int(30) DEFAULT '0',
  `tracking` int(11) DEFAULT '0',
  `time_spent` int(11) DEFAULT '0',
  `milestone_id` int(11) DEFAULT '0',
  `invoice_id` int(60) DEFAULT '0',
  `milestone_order` int(11) DEFAULT '0',
  `task_order` int(11) DEFAULT '0',
  `progress` int(11) DEFAULT '0',
  `created_at` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `start_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`) VALUES ('1', '1', 'Dimensionar a Usina', '1', 'open', '1', NULL, '2018-12-08', '', '2018-12-04', '0', '2', NULL, '0', '0', '0', '0', '1', '0', '1', '0', '0', '2018-11-26 11:27:24');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `start_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`) VALUES ('2', '1', 'Dar nome pra Usina', '1', 'open', '1', NULL, '2018-12-08', '', '2018-12-05', '0', '2', NULL, '0', '0', '0', '0', '1', '0', '0', '0', '0', '2018-11-26 11:54:26');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `start_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`) VALUES ('3', '3', 'Subir os arquivos para o Google Drive', '1', 'open', '0', NULL, '2018-12-09', '', '2018-11-29', '0', '2', NULL, '0', '0', '0', '61', '2', '0', '1', '0', '0', '2018-11-27 13:48:23');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `start_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`) VALUES ('4', '3', 'Tarefa BBB 1', '1', 'open', '0', NULL, '2018-12-03', '', '2018-11-30', '0', '2', NULL, '0', '0', '0', '0', '3', '0', '1', '0', '0', '2018-11-28 17:34:22');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `start_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`) VALUES ('5', '3', 'Tarefa BBB 2', '1', 'open', '0', NULL, '2018-12-05', '', '2018-12-02', '0', '1', NULL, '0', '0', '0', '0', '3', '0', '2', '0', '0', '2018-11-28 17:34:29');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `start_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`) VALUES ('6', '3', 'Tarefa BBB 3', '1', 'open', '0', NULL, '2018-12-13', '', '2018-12-08', '0', '3', NULL, '0', '0', '0', '0', '3', '0', '3', '0', '0', '2018-11-28 17:34:36');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `start_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`) VALUES ('7', '3', 'Tarefa CCC 1', '1', 'done', '0', NULL, '2018-12-18', '', '2018-12-15', '0', '1', NULL, '0', '0', '0', '0', '4', '0', '2', '0', '0', '2018-11-28 17:34:44');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `start_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`) VALUES ('8', '3', 'Tarefa CCC 2', '1', 'open', '0', NULL, '2018-12-22', '', '2018-12-19', '0', '2', NULL, '0', '0', '0', '0', '4', '0', '3', '0', '0', '2018-11-28 17:34:54');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `start_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`) VALUES ('9', '3', 'Tarefa CCC 3', '1', 'done', '0', NULL, '2018-12-21', '', '2019-01-17', '0', '3', NULL, '0', '0', '0', '0', '4', '0', '4', '0', '0', '2018-11-28 17:35:01');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `start_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`) VALUES ('10', '3', 'Tarefa CCC 4', '1', 'open', '0', NULL, '2018-12-25', '', '2018-12-22', '0', '1', NULL, '0', '0', '0', '0', '4', '0', '5', '0', '0', '2018-11-28 17:35:09');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `start_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`) VALUES ('11', '3', 'Pagamento da 1a parcela', '0', 'open', '1', NULL, '2018-12-07', '', '2018-12-04', '0', '3', NULL, '3', '0', '0', '2', '0', '0', '1', '0', '0', '2018-12-04 17:00:12');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `start_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`) VALUES ('12', '4', 'Subir os arquivos para o Google Drive', '0', 'open', '0', '2018', '2019-02-06', '', NULL, '0', '2', NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', '2018-12-05 15:50:05');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `start_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`) VALUES ('13', '4', 'Tarefa BBB 1', '0', 'open', '0', '2018', '2019-02-06', '', NULL, '0', '2', NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', '2018-12-05 15:50:05');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `start_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`) VALUES ('14', '4', 'Tarefa BBB 2', '0', 'open', '0', '2018', '2019-02-06', '', NULL, '0', '1', NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', '2018-12-05 15:50:05');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `start_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`) VALUES ('15', '4', 'Tarefa BBB 3', '0', 'open', '0', '2018', '2019-02-06', '', NULL, '0', '3', NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', '2018-12-05 15:50:05');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `start_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`) VALUES ('16', '4', 'Tarefa CCC 1', '0', 'open', '0', '2018', '2019-02-06', '', NULL, '0', '1', NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', '2018-12-05 15:50:05');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `start_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`) VALUES ('17', '4', 'Tarefa CCC 2', '0', 'open', '0', '2018', '2019-02-06', '', NULL, '0', '2', NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', '2018-12-05 15:50:05');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `start_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`) VALUES ('18', '4', 'Tarefa CCC 3', '0', 'open', '0', '2018', '2019-02-06', '', NULL, '0', '3', NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', '2018-12-05 15:50:05');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `start_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`) VALUES ('19', '4', 'Tarefa CCC 4', '0', 'open', '0', '2018', '2019-02-06', '', NULL, '0', '1', NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', '2018-12-05 15:50:05');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `start_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`) VALUES ('20', '4', 'Pagamento da 1a parcela', '0', 'open', '1', '2018', '2019-02-06', '', NULL, '0', '3', NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', '2018-12-05 15:50:05');


#
# TABLE STRUCTURE FOR: project_has_timesheets
#

DROP TABLE IF EXISTS project_has_timesheets;

CREATE TABLE `project_has_timesheets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `time` varchar(250) DEFAULT '0',
  `task_id` int(11) DEFAULT '0',
  `client_id` int(11) DEFAULT '0',
  `start` varchar(250) DEFAULT '0',
  `end` varchar(250) DEFAULT '0',
  `invoice_id` int(11) DEFAULT '0',
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO project_has_timesheets (`id`, `project_id`, `user_id`, `time`, `task_id`, `client_id`, `start`, `end`, `invoice_id`, `description`) VALUES ('1', '3', '1', '14', '3', '0', '1543429668', '1543429682', '0', NULL);
INSERT INTO project_has_timesheets (`id`, `project_id`, `user_id`, `time`, `task_id`, `client_id`, `start`, `end`, `invoice_id`, `description`) VALUES ('2', '3', '1', '12120', '3', '0', '1543413600', '1543413600', '0', '');
INSERT INTO project_has_timesheets (`id`, `project_id`, `user_id`, `time`, `task_id`, `client_id`, `start`, `end`, `invoice_id`, `description`) VALUES ('3', '3', '1', '29', '3', '0', '1543429713', '1543429742', '0', NULL);
INSERT INTO project_has_timesheets (`id`, `project_id`, `user_id`, `time`, `task_id`, `client_id`, `start`, `end`, `invoice_id`, `description`) VALUES ('4', '3', '1', '1', '3', '0', '1543429987', '1543429988', '0', NULL);


#
# TABLE STRUCTURE FOR: project_has_workers
#

DROP TABLE IF EXISTS project_has_workers;

CREATE TABLE `project_has_workers` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `project_id` int(10) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('1', '1', '1');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('2', '2', '1');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('4', '3', '4');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('5', '2', '4');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('6', '2', '2');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('7', '2', '3');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('8', '1', '2');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('9', '1', '4');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('10', '3', '1');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('11', '4', '1');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('12', '5', '1');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('13', '6', '1');


#
# TABLE STRUCTURE FOR: projects
#

DROP TABLE IF EXISTS projects;

CREATE TABLE `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` int(11) DEFAULT '0',
  `name` varchar(65) DEFAULT NULL,
  `description` text,
  `start` varchar(20) DEFAULT NULL,
  `end` varchar(20) DEFAULT NULL,
  `progress` decimal(3,0) DEFAULT NULL,
  `phases` varchar(150) DEFAULT NULL,
  `tracking` int(11) DEFAULT '0',
  `time_spent` int(11) DEFAULT '0',
  `datetime` int(11) DEFAULT '0',
  `sticky` enum('1','0') DEFAULT '0',
  `category` varchar(150) DEFAULT NULL,
  `company_id` int(11) DEFAULT '0',
  `note` longtext,
  `progress_calc` tinyint(4) DEFAULT '0',
  `hide_tasks` int(1) DEFAULT '0',
  `enable_client_tasks` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO projects (`id`, `reference`, `name`, `description`, `start`, `end`, `progress`, `phases`, `tracking`, `time_spent`, `datetime`, `sticky`, `category`, `company_id`, `note`, `progress_calc`, `hide_tasks`, `enable_client_tasks`) VALUES ('1', '51001', 'UFV001 - Google Inc', '', '2018-11-26', '2019-01-31', '0', 'Planejamento, Desenvolvimento, Testes', '0', '0', '1543238551', '0', 'bgColor9', '1', '&lt;p&gt;Notas compartilhadas&lt;/p&gt;', '1', '0', '0');
INSERT INTO projects (`id`, `reference`, `name`, `description`, `start`, `end`, `progress`, `phases`, `tracking`, `time_spent`, `datetime`, `sticky`, `category`, `company_id`, `note`, `progress_calc`, `hide_tasks`, `enable_client_tasks`) VALUES ('2', '51002', 'UFV002 - Apple Inc', '', '2018-11-27', '2019-01-15', '0', 'Planejamento, Desenvolvimento, Testes', '0', '0', '1543262073', '1', 'bgColor3', '2', NULL, '1', '0', '0');
INSERT INTO projects (`id`, `reference`, `name`, `description`, `start`, `end`, `progress`, `phases`, `tracking`, `time_spent`, `datetime`, `sticky`, `category`, `company_id`, `note`, `progress_calc`, `hide_tasks`, `enable_client_tasks`) VALUES ('3', '51003', 'UFV003 - Samsung Eletronics Co.', 'Descrição do projeto UFV003 - Samsung Eletronics Co.', '2018-11-30', '2018-12-25', '22', 'Planejamento, Desenvolvimento, Testes', '0', '9600', '1543262315', '0', 'bgColor1', '3', NULL, '1', '0', '0');
INSERT INTO projects (`id`, `reference`, `name`, `description`, `start`, `end`, `progress`, `phases`, `tracking`, `time_spent`, `datetime`, `sticky`, `category`, `company_id`, `note`, `progress_calc`, `hide_tasks`, `enable_client_tasks`) VALUES ('4', '51004', 'UFV003 - Samsung Eletronics Co. Segunda versão', 'Descrição do projeto UFV003 - Samsung Eletronics Co.', '2018-12-08', '2019-02-06', '22', 'Planejamento, Desenvolvimento, Testes', '0', '0', '1544032205', '0', 'bgColor9', '3', NULL, '0', '0', '0');


#
# TABLE STRUCTURE FOR: pw_reset
#

DROP TABLE IF EXISTS pw_reset;

CREATE TABLE `pw_reset` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `email` varchar(250) DEFAULT NULL,
  `timestamp` varchar(250) DEFAULT NULL,
  `token` varchar(250) DEFAULT NULL,
  `user` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: queues
#

DROP TABLE IF EXISTS queues;

CREATE TABLE `queues` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL,
  `inactive` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO queues (`id`, `name`, `description`, `inactive`) VALUES ('1', 'Comercial', 'Fila de tickets sobre área comercial', '0');
INSERT INTO queues (`id`, `name`, `description`, `inactive`) VALUES ('2', 'Financeiro', 'Fila de tickets sobre área financeira', '0');
INSERT INTO queues (`id`, `name`, `description`, `inactive`) VALUES ('3', 'Engenharia', 'Fila de tickets sobre área de Engenharia', '0');
INSERT INTO queues (`id`, `name`, `description`, `inactive`) VALUES ('4', 'Tecnologia da Informação', 'Fila de tickets da área de Tecnologia da Informação', '0');


#
# TABLE STRUCTURE FOR: quotations
#

DROP TABLE IF EXISTS quotations;

CREATE TABLE `quotations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `q1` varchar(50) DEFAULT NULL,
  `q2` varchar(50) DEFAULT NULL,
  `q3` varchar(50) DEFAULT NULL,
  `q4` varchar(150) DEFAULT NULL,
  `q5` text,
  `q6` varchar(50) DEFAULT NULL,
  `company` varchar(150) DEFAULT '-',
  `fullname` varchar(150) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `phone` varchar(150) DEFAULT NULL,
  `address` varchar(150) DEFAULT NULL,
  `city` varchar(150) DEFAULT NULL,
  `zip` varchar(150) DEFAULT NULL,
  `country` varchar(150) DEFAULT NULL,
  `comment` text,
  `date` varchar(50) DEFAULT NULL,
  `status` varchar(150) DEFAULT NULL,
  `user_id` int(50) DEFAULT '0',
  `replied` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: reminders
#

DROP TABLE IF EXISTS reminders;

CREATE TABLE `reminders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(250) DEFAULT NULL,
  `source_id` bigint(20) DEFAULT '0',
  `title` varchar(250) DEFAULT NULL,
  `body` text,
  `email_notification` int(1) DEFAULT '0',
  `done` int(1) DEFAULT '0',
  `datetime` varchar(50) DEFAULT NULL,
  `sent_at` varchar(50) DEFAULT NULL,
  `user_id` int(20) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: subscription_has_items
#

DROP TABLE IF EXISTS subscription_has_items;

CREATE TABLE `subscription_has_items` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `subscription_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `amount` char(11) DEFAULT '0',
  `description` mediumtext,
  `value` float DEFAULT '0',
  `name` varchar(250) DEFAULT NULL,
  `type` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: subscriptions
#

DROP TABLE IF EXISTS subscriptions;

CREATE TABLE `subscriptions` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `reference` varchar(50) DEFAULT NULL,
  `company_id` int(10) DEFAULT '0',
  `status` varchar(50) DEFAULT NULL,
  `currency` varchar(20) DEFAULT NULL,
  `issue_date` varchar(20) DEFAULT NULL,
  `end_date` varchar(20) DEFAULT NULL,
  `frequency` varchar(20) DEFAULT NULL,
  `next_payment` varchar(20) DEFAULT NULL,
  `terms` mediumtext,
  `discount` varchar(50) DEFAULT NULL,
  `tax` varchar(250) DEFAULT NULL,
  `second_tax` varchar(255) DEFAULT NULL,
  `subscribed` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: task_has_comments
#

DROP TABLE IF EXISTS task_has_comments;

CREATE TABLE `task_has_comments` (
  `id` bigint(255) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `client_id` int(11) DEFAULT NULL,
  `message` text,
  `datetime` varchar(20) DEFAULT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `task_id` bigint(20) DEFAULT NULL,
  `attachment_link` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: templates
#

DROP TABLE IF EXISTS templates;

CREATE TABLE `templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(250) NOT NULL,
  `name` varchar(250) NOT NULL,
  `text` text,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ticket_has_articles
#

DROP TABLE IF EXISTS ticket_has_articles;

CREATE TABLE `ticket_has_articles` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) DEFAULT '0',
  `from` varchar(250) NOT NULL,
  `reply_to` varchar(250) DEFAULT NULL,
  `to` varchar(250) DEFAULT NULL,
  `cc` varchar(250) DEFAULT NULL,
  `subject` varchar(250) DEFAULT NULL,
  `message` text,
  `datetime` varchar(250) DEFAULT NULL,
  `internal` int(10) DEFAULT '1',
  `user_id` bigint(20) DEFAULT '0',
  `note` int(1) DEFAULT '0',
  `raw` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO ticket_has_articles (`id`, `ticket_id`, `from`, `reply_to`, `to`, `cc`, `subject`, `message`, `datetime`, `internal`, `user_id`, `note`, `raw`) VALUES ('1', '1', 'Thiago Pires - thiago.pires@ownergy.com.br', 'thiago.pires@ownergy.com.br', 'zenit.cliente@ownergy.com.br', NULL, 'Visita não aconteceu', 'O Rildo me disse que ele adoeceu, ele vai amanhã.<p class=\"signature\" unselectable=\"on\" contenteditable=\"false\">Thiago Pires</p>', '1543239043', '0', '1', '0', NULL);
INSERT INTO ticket_has_articles (`id`, `ticket_id`, `from`, `reply_to`, `to`, `cc`, `subject`, `message`, `datetime`, `internal`, `user_id`, `note`, `raw`) VALUES ('2', '2', 'Thiago Pires - zenit.colaborador@ownergy.com.br', 'zenit.colaborador@ownergy.com.br', '2', NULL, 'Ticket atribuído', '', '1543333743', '1', '0', '0', NULL);
INSERT INTO ticket_has_articles (`id`, `ticket_id`, `from`, `reply_to`, `to`, `cc`, `subject`, `message`, `datetime`, `internal`, `user_id`, `note`, `raw`) VALUES ('3', '3', 'Thiago Pires - zenit.colaborador@ownergy.com.br', 'zenit.colaborador@ownergy.com.br', NULL, NULL, '', '', '1543516889', '1', '1', '1', NULL);
INSERT INTO ticket_has_articles (`id`, `ticket_id`, `from`, `reply_to`, `to`, `cc`, `subject`, `message`, `datetime`, `internal`, `user_id`, `note`, `raw`) VALUES ('4', '2', 'Thiago Pires - thiago.pires@ownergy.com.br', 'thiago.pires@ownergy.com.br', 'zenit.cliente@ownergy.com.br', NULL, 'Usina pouco efetiva', ' Teste de resposta<br contenteditable=\"false\"> <p class=\"signature\" unselectable=\"on\" contenteditable=\"false\">Thiago Pires</p>', '1544097687', '0', '1', '0', NULL);


#
# TABLE STRUCTURE FOR: ticket_has_attachments
#

DROP TABLE IF EXISTS ticket_has_attachments;

CREATE TABLE `ticket_has_attachments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ticket_id` bigint(20) DEFAULT NULL,
  `filename` varchar(250) DEFAULT NULL,
  `savename` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO ticket_has_attachments (`id`, `ticket_id`, `filename`, `savename`) VALUES ('1', '4', 'user.png', 'def54bd95641bac4ba44043f2b26ce0c.png');


#
# TABLE STRUCTURE FOR: tickets
#

DROP TABLE IF EXISTS tickets;

CREATE TABLE `tickets` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `from` varchar(250) DEFAULT NULL,
  `reference` varchar(250) DEFAULT NULL,
  `type_id` smallint(6) DEFAULT '1',
  `lock` smallint(6) DEFAULT NULL,
  `subject` varchar(250) DEFAULT NULL,
  `text` text,
  `status` varchar(50) DEFAULT NULL,
  `client_id` int(11) DEFAULT '0',
  `company_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `escalation_time` int(11) DEFAULT '0',
  `priority` varchar(50) DEFAULT NULL,
  `created` int(11) DEFAULT '0',
  `queue_id` int(11) DEFAULT '0',
  `updated` tinyint(4) DEFAULT '0',
  `project_id` bigint(20) DEFAULT '0',
  `raw` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO tickets (`id`, `from`, `reference`, `type_id`, `lock`, `subject`, `text`, `status`, `client_id`, `company_id`, `user_id`, `escalation_time`, `priority`, `created`, `queue_id`, `updated`, `project_id`, `raw`) VALUES ('1', 'Ingred Preis - zenit.cliente@ownergy.com.br', '10000', '1', NULL, 'Visita não aconteceu', '<p>O <b><u><font color=\"#ff0000\">Rildo</font></u></b> me falou que viria verificar um dado no meu telhado, mas não apareceu.</p>', 'reopened', '1', '1', '1', '0', NULL, '1543238975', '1', '0', '0', NULL);
INSERT INTO tickets (`id`, `from`, `reference`, `type_id`, `lock`, `subject`, `text`, `status`, `client_id`, `company_id`, `user_id`, `escalation_time`, `priority`, `created`, `queue_id`, `updated`, `project_id`, `raw`) VALUES ('2', 'Ingred Preis - zenit.cliente@ownergy.com.br', '10001', '1', NULL, 'Usina pouco efetiva', '<p>Minha usina está gerando menos do que o normal<br></p>', 'open', '1', '1', '2', '0', NULL, '1543250016', '3', '0', '0', NULL);
INSERT INTO tickets (`id`, `from`, `reference`, `type_id`, `lock`, `subject`, `text`, `status`, `client_id`, `company_id`, `user_id`, `escalation_time`, `priority`, `created`, `queue_id`, `updated`, `project_id`, `raw`) VALUES ('3', 'Matheus Castro - zenit.cliente3@ownergy.com.br', '10002', '1', NULL, 'Painel torto', '<p>Um painel ficou torto ao instalar a usina</p>', 'closed', '3', '3', '1', '0', NULL, '1543333950', '1', '0', '0', NULL);
INSERT INTO tickets (`id`, `from`, `reference`, `type_id`, `lock`, `subject`, `text`, `status`, `client_id`, `company_id`, `user_id`, `escalation_time`, `priority`, `created`, `queue_id`, `updated`, `project_id`, `raw`) VALUES ('4', 'Ingred Preis - zenit.cliente@ownergy.com.br', '10003', '1', NULL, 'Minha usina não funciona', '<p>Paguei conta mais cara</p>', 'closed', '1', '1', '1', '0', NULL, '1543434481', '1', '0', '0', NULL);


#
# TABLE STRUCTURE FOR: types
#

DROP TABLE IF EXISTS types;

CREATE TABLE `types` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL,
  `inactive` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO types (`id`, `name`, `description`, `inactive`) VALUES ('1', 'Prevenção', 'Tickets de prevenção', '0');
INSERT INTO types (`id`, `name`, `description`, `inactive`) VALUES ('2', 'Remediação', 'Tickets de remediação', '0');
INSERT INTO types (`id`, `name`, `description`, `inactive`) VALUES ('3', 'Solicitação de cliente', 'Tickets de solicitações de clientes', '0');
INSERT INTO types (`id`, `name`, `description`, `inactive`) VALUES ('4', 'Investigação', 'Tickets de investigação', '0');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS users;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(45) DEFAULT NULL,
  `firstname` varchar(120) DEFAULT NULL,
  `lastname` varchar(120) DEFAULT NULL,
  `hashed_password` varchar(128) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `status` enum('active','inactive','deleted') DEFAULT NULL,
  `admin` enum('0','1') DEFAULT '0',
  `created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `userpic` varchar(250) DEFAULT 'no-pic.png',
  `title` varchar(150) DEFAULT NULL,
  `access` varchar(150) NOT NULL DEFAULT '1,2',
  `last_active` varchar(50) DEFAULT NULL,
  `last_login` varchar(50) DEFAULT NULL,
  `queue` bigint(20) DEFAULT '0',
  `token` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `signature` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO users (`id`, `username`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `last_active`, `last_login`, `queue`, `token`, `language`, `signature`) VALUES ('1', 'thiago.pires', 'Thiago', 'Pires', '3048405e5d403b655b452b316e2566325d4d4d625c565d4e7654626358572743b1dd243ebe064dd6095e80fbfb32b0a767c20c8db0b334fd189f5e8de98a0231', 'thiago.pires@ownergy.com.br', 'active', '1', '2018-11-26 09:41:06', '6fdd78a61e9e88a8388f81c147e1a056.png', 'Analista de Invoação', '1,2,3,4,20,105,9,10,11', '1544187088', '1544182983', '1', '8dacf92301e47aa845f807057cd04abc', NULL, 'Thiago Pires');
INSERT INTO users (`id`, `username`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `last_active`, `last_login`, `queue`, `token`, `language`, `signature`) VALUES ('2', 'alan.barros', 'Alan', 'Barros', '6e21496b41506b664a312d5a3c364639377640263b4452555a6f243274367b2343588035adaf173809b650dfd53b50eb71043ca008c025a8cbc866a00f64494a', 'zenit.colaborador2@ownergy.com.br', 'active', '0', '2018-11-26 17:25:22', 'ce0fbef22baed51e4d43dc5d8dc72da8.jpg', 'Analista de Projetos', '1,2,3,20,105,10,11', NULL, NULL, '3', NULL, NULL, 'Alan Barros');
INSERT INTO users (`id`, `username`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `last_active`, `last_login`, `queue`, `token`, `language`, `signature`) VALUES ('3', 'marlem.batista', 'Marlem', 'Batista', '5f4f7c496f7767384b794c5d3b4265222a65396928295277313945433a27216f29a5dab440bcbe087f66f3337bdbd36f1492d7c6e94b3e0684bed730a63bf18f', 'zenit.colaborador3@ownergy.com.br', 'active', '0', '2018-11-26 17:27:48', '109d0d4faa1f1cd342648cfebf00bf07.jpg', 'Analista Administrativo', '1,2,3,20,105,10,11', '0', '1543518683', '2', NULL, NULL, 'Marlem Batista');
INSERT INTO users (`id`, `username`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `last_active`, `last_login`, `queue`, `token`, `language`, `signature`) VALUES ('4', 'jorge.felipe', 'Jorge', 'Felipe', '4e324b235c545671293f702d245e59464b5e79693a6664577a727933442949599ff5f2e448ad644083fd35b2ba4389a077a71dc49e098af409fb900a99d9d509', 'zenit.colaborador4@ownergy.com.br', 'active', '0', '2018-11-26 17:29:44', 'f712d5ae08766215927722e374f49cbb.jpg', 'Coordenador de Projetos', '1,2,3,4,20,105,10,11', '0', '1544033472', '1', NULL, NULL, 'Jorge Felipe B. Mota');


