#
# TABLE STRUCTURE FOR: article_has_attachments
#

DROP TABLE IF EXISTS article_has_attachments;

CREATE TABLE `article_has_attachments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `article_id` bigint(20) DEFAULT NULL,
  `filename` varchar(250) DEFAULT NULL,
  `savename` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: clients
#

DROP TABLE IF EXISTS clients;

CREATE TABLE `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(140) DEFAULT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `email` varchar(180) DEFAULT NULL,
  `phone` varchar(25) DEFAULT NULL,
  `mobile` varchar(25) DEFAULT NULL,
  `address` varchar(150) DEFAULT NULL,
  `zipcode` varchar(30) DEFAULT NULL,
  `userpic` varchar(150) DEFAULT 'no-pic.png',
  `city` varchar(45) DEFAULT NULL,
  `hashed_password` varchar(255) DEFAULT NULL,
  `inactive` tinyint(4) DEFAULT '0',
  `access` varchar(150) DEFAULT '0',
  `last_active` varchar(50) DEFAULT NULL,
  `last_login` varchar(50) DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `signature` text,
  `push_active` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`, `token`, `language`, `signature`, `push_active`) VALUES ('2', '2', 'Matheus', 'Pires', 'zenit.cliente@ownergy.com.br', '', '', '', '', 'no-pic.png', '', '2a3f38743f2a235d385268613c40247d7a795a2c643b4644345f2d5246636a4eb80ebc1541711fe3ef18ce4072a60ab49c63f0c7ce9bb37f262d5ea91fe2bfdb', '0', '103,101,106', '1545326951', '1545309136', NULL, NULL, NULL, '0');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`, `token`, `language`, `signature`, `push_active`) VALUES ('3', '3', 'Ingred', 'Preis', 'zenit.cliente2@ownergy.com.br', '', '', '', '', 'no-pic.png', '', '41555d2f614855404a567033394c3b34493d3070722a2c26263a7547706a4f5c8c38dcb4096d501e5df4a6f82704c990acca66ef86beb8752de260cea7ee9637', '0', '103,101,106', NULL, NULL, NULL, NULL, NULL, '0');


#
# TABLE STRUCTURE FOR: companies
#

DROP TABLE IF EXISTS companies;

CREATE TABLE `companies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` int(11) NOT NULL,
  `name` varchar(140) DEFAULT NULL,
  `client_id` varchar(140) DEFAULT NULL,
  `phone` varchar(25) DEFAULT NULL,
  `mobile` varchar(25) DEFAULT NULL,
  `address` varchar(150) DEFAULT NULL,
  `zipcode` varchar(30) NOT NULL,
  `city` varchar(45) DEFAULT NULL,
  `inactive` tinyint(4) DEFAULT '0',
  `website` varchar(250) DEFAULT NULL,
  `country` varchar(250) DEFAULT NULL,
  `vat` varchar(250) DEFAULT NULL,
  `note` longtext,
  `province` varchar(255) DEFAULT NULL,
  `terms` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`, `terms`) VALUES ('1', '1000', 'Google Inc', '1', '(31)3333-3333', '(31)9999-9999', 'Rua do Google, 100', '31000-100', 'Belo Horizonte', '1', NULL, 'Brasil', NULL, NULL, 'MG', '');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`, `terms`) VALUES ('2', '1001', 'Google Inc', '2', '', '', 'Rua do Google, 100', '31000-100', 'Belo Horizonte', '0', NULL, 'Brasil', NULL, NULL, 'MG', '');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`, `terms`) VALUES ('3', '1002', 'Apple Inc', '3', '', '', 'Rua da Apple, 200', '31000-200', 'Belo Horizonte', '0', NULL, 'Brasil', NULL, NULL, 'MG', '');


#
# TABLE STRUCTURE FOR: company_has_admins
#

DROP TABLE IF EXISTS company_has_admins;

CREATE TABLE `company_has_admins` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `company_id` int(10) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  `access` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO company_has_admins (`id`, `company_id`, `user_id`, `access`) VALUES ('1', '1', '1', NULL);
INSERT INTO company_has_admins (`id`, `company_id`, `user_id`, `access`) VALUES ('2', '2', '2', NULL);
INSERT INTO company_has_admins (`id`, `company_id`, `user_id`, `access`) VALUES ('3', '2', '1', NULL);
INSERT INTO company_has_admins (`id`, `company_id`, `user_id`, `access`) VALUES ('4', '3', '1', NULL);


#
# TABLE STRUCTURE FOR: core
#

DROP TABLE IF EXISTS core;

CREATE TABLE `core` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` char(10) NOT NULL DEFAULT '0',
  `domain` varchar(65) DEFAULT NULL,
  `email` varchar(80) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `tax` varchar(5) DEFAULT NULL,
  `second_tax` varchar(5) DEFAULT NULL,
  `currency` varchar(20) DEFAULT NULL,
  `autobackup` int(11) DEFAULT NULL,
  `cronjob` int(11) DEFAULT NULL,
  `last_cronjob` int(11) DEFAULT NULL,
  `last_autobackup` int(11) DEFAULT NULL,
  `invoice_terms` mediumtext,
  `company_reference` int(6) DEFAULT NULL,
  `project_reference` int(6) DEFAULT NULL,
  `invoice_reference` int(6) DEFAULT NULL,
  `subscription_reference` int(6) DEFAULT NULL,
  `ticket_reference` int(10) DEFAULT NULL,
  `date_format` varchar(20) DEFAULT NULL,
  `date_time_format` varchar(20) DEFAULT NULL,
  `invoice_mail_subject` varchar(150) DEFAULT NULL,
  `pw_reset_mail_subject` varchar(150) DEFAULT NULL,
  `pw_reset_link_mail_subject` varchar(150) DEFAULT NULL,
  `credentials_mail_subject` varchar(150) DEFAULT NULL,
  `notification_mail_subject` varchar(150) DEFAULT NULL,
  `language` varchar(150) DEFAULT NULL,
  `invoice_address` varchar(200) DEFAULT NULL,
  `invoice_city` varchar(200) DEFAULT NULL,
  `invoice_contact` varchar(200) DEFAULT NULL,
  `invoice_tel` varchar(50) DEFAULT NULL,
  `subscription_mail_subject` varchar(250) DEFAULT NULL,
  `logo` varchar(150) DEFAULT NULL,
  `template` varchar(200) DEFAULT 'default',
  `paypal` varchar(5) DEFAULT '1',
  `paypal_currency` varchar(200) DEFAULT 'EUR',
  `paypal_account` varchar(200) DEFAULT 'luxsys@luxsys-apps.com',
  `invoice_logo` varchar(150) DEFAULT 'assets/blackline/img/invoice_logo.png',
  `pc` varchar(150) DEFAULT NULL,
  `vat` varchar(150) DEFAULT NULL,
  `ticket_email` varchar(250) DEFAULT NULL,
  `ticket_default_owner` int(10) DEFAULT '1',
  `ticket_default_queue` int(10) DEFAULT '1',
  `ticket_default_type` int(10) DEFAULT '1',
  `ticket_default_status` varchar(200) DEFAULT 'new',
  `ticket_config_host` varchar(250) DEFAULT NULL,
  `ticket_config_login` varchar(250) DEFAULT NULL,
  `ticket_config_pass` varchar(250) DEFAULT NULL,
  `ticket_config_port` varchar(250) DEFAULT NULL,
  `ticket_config_ssl` varchar(250) DEFAULT NULL,
  `ticket_config_email` varchar(250) DEFAULT NULL,
  `ticket_config_flags` varchar(250) DEFAULT '/notls',
  `ticket_config_search` varchar(250) DEFAULT 'UNSEEN',
  `ticket_config_timestamp` int(11) DEFAULT NULL,
  `ticket_config_mailbox` varchar(250) DEFAULT NULL,
  `ticket_config_delete` int(11) DEFAULT NULL,
  `ticket_config_active` int(11) DEFAULT NULL,
  `ticket_config_imap` int(11) DEFAULT '1',
  `stripe` int(11) DEFAULT '0',
  `stripe_key` varchar(250) DEFAULT NULL,
  `stripe_p_key` varchar(255) DEFAULT NULL,
  `bank_transfer` int(11) DEFAULT NULL,
  `bank_transfer_text` longtext,
  `stripe_currency` varchar(255) NOT NULL DEFAULT 'USD',
  `estimate_terms` longtext,
  `estimate_prefix` varchar(255) NOT NULL DEFAULT 'EST',
  `estimate_pdf_template` varchar(255) NOT NULL DEFAULT 'templates/estimate/default',
  `invoice_pdf_template` varchar(255) NOT NULL DEFAULT 'invoices/preview',
  `estimate_mail_subject` varchar(255) NOT NULL DEFAULT 'New Estimate #{estimate_id}',
  `money_currency_position` int(5) NOT NULL DEFAULT '1',
  `money_format` int(5) NOT NULL DEFAULT '1',
  `pdf_font` varchar(255) NOT NULL DEFAULT 'NotoSans',
  `pdf_path` int(10) NOT NULL DEFAULT '1',
  `registration` int(10) NOT NULL DEFAULT '0',
  `authorize_api_login_id` varchar(255) DEFAULT NULL,
  `authorize_api_transaction_key` varchar(255) DEFAULT NULL,
  `authorize_net` int(20) DEFAULT '0',
  `authorize_currency` varchar(30) DEFAULT NULL,
  `invoice_prefix` varchar(255) DEFAULT NULL,
  `company_prefix` varchar(255) DEFAULT NULL,
  `quotation_prefix` varchar(255) DEFAULT NULL,
  `project_prefix` varchar(255) DEFAULT NULL,
  `subscription_prefix` varchar(255) DEFAULT NULL,
  `calendar_google_api_key` varchar(255) DEFAULT NULL,
  `calendar_google_event_address` varchar(255) DEFAULT NULL,
  `default_client_modules` varchar(255) DEFAULT NULL,
  `estimate_reference` int(10) DEFAULT '0',
  `login_background` varchar(255) DEFAULT 'blur.jpg',
  `custom_colors` int(1) DEFAULT '1',
  `top_bar_background` varchar(60) DEFAULT '#FFFFFF',
  `top_bar_color` varchar(60) DEFAULT '#333333',
  `body_background` varchar(60) DEFAULT '#e3e6ed',
  `menu_background` varchar(60) DEFAULT '#173240',
  `menu_color` varchar(60) DEFAULT '#FFFFFF',
  `primary_color` varchar(60) DEFAULT '#356cc9',
  `twocheckout_seller_id` varchar(250) DEFAULT NULL,
  `twocheckout_publishable_key` varchar(250) DEFAULT NULL,
  `twocheckout_private_key` varchar(250) DEFAULT NULL,
  `twocheckout` int(11) DEFAULT '0',
  `twocheckout_currency` varchar(250) DEFAULT NULL,
  `login_logo` varchar(255) DEFAULT NULL,
  `login_style` varchar(255) DEFAULT 'left',
  `reference_lenght` int(20) DEFAULT NULL,
  `stripe_ideal` int(1) DEFAULT NULL,
  `zip_position` varchar(60) DEFAULT 'left',
  `timezone` varchar(255) DEFAULT NULL,
  `notifications` int(1) unsigned DEFAULT '0',
  `last_notification` varchar(100) DEFAULT NULL,
  `receipt_mail_subject` varchar(200) DEFAULT NULL,
  `push_active` tinyint(1) NOT NULL DEFAULT '0',
  `push_rest_api_key` varchar(50) DEFAULT NULL,
  `push_app_id` varchar(50) DEFAULT NULL,
  `money_symbol` varchar(10) NOT NULL,
  `rated_power_measurement` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO core (`id`, `version`, `domain`, `email`, `company`, `tax`, `second_tax`, `currency`, `autobackup`, `cronjob`, `last_cronjob`, `last_autobackup`, `invoice_terms`, `company_reference`, `project_reference`, `invoice_reference`, `subscription_reference`, `ticket_reference`, `date_format`, `date_time_format`, `invoice_mail_subject`, `pw_reset_mail_subject`, `pw_reset_link_mail_subject`, `credentials_mail_subject`, `notification_mail_subject`, `language`, `invoice_address`, `invoice_city`, `invoice_contact`, `invoice_tel`, `subscription_mail_subject`, `logo`, `template`, `paypal`, `paypal_currency`, `paypal_account`, `invoice_logo`, `pc`, `vat`, `ticket_email`, `ticket_default_owner`, `ticket_default_queue`, `ticket_default_type`, `ticket_default_status`, `ticket_config_host`, `ticket_config_login`, `ticket_config_pass`, `ticket_config_port`, `ticket_config_ssl`, `ticket_config_email`, `ticket_config_flags`, `ticket_config_search`, `ticket_config_timestamp`, `ticket_config_mailbox`, `ticket_config_delete`, `ticket_config_active`, `ticket_config_imap`, `stripe`, `stripe_key`, `stripe_p_key`, `bank_transfer`, `bank_transfer_text`, `stripe_currency`, `estimate_terms`, `estimate_prefix`, `estimate_pdf_template`, `invoice_pdf_template`, `estimate_mail_subject`, `money_currency_position`, `money_format`, `pdf_font`, `pdf_path`, `registration`, `authorize_api_login_id`, `authorize_api_transaction_key`, `authorize_net`, `authorize_currency`, `invoice_prefix`, `company_prefix`, `quotation_prefix`, `project_prefix`, `subscription_prefix`, `calendar_google_api_key`, `calendar_google_event_address`, `default_client_modules`, `estimate_reference`, `login_background`, `custom_colors`, `top_bar_background`, `top_bar_color`, `body_background`, `menu_background`, `menu_color`, `primary_color`, `twocheckout_seller_id`, `twocheckout_publishable_key`, `twocheckout_private_key`, `twocheckout`, `twocheckout_currency`, `login_logo`, `login_style`, `reference_lenght`, `stripe_ideal`, `zip_position`, `timezone`, `notifications`, `last_notification`, `receipt_mail_subject`, `push_active`, `push_rest_api_key`, `push_app_id`, `money_symbol`, `rated_power_measurement`) VALUES ('1', '1.0.0', 'http://localhost/zenit/', 'contato@ownergy.com.br', 'Ownergy Solar', '0', '', 'BRL', '1', '1', '1552670158', '1552670158', '', '1003', '3', '8000', '9000', '5001', 'd/m/Y', 'H:i', 'New Invoice', 'Password Reset', 'Password Reset', 'Login Details', 'Notification', 'portuguese', 'Rua Araguari, 1156, 1301, Santo Agostinho', 'Belo Horizonte', '(31) 3654-0098', '(31) 3654-0098', 'New Subscription', 'files/media/zenit_logo_dev.png', 'blueline', '0', 'BRL', '', 'files/media/ownergy_logo.png', 'nulled', '', NULL, '1', '1', '1', 'new', NULL, NULL, NULL, NULL, NULL, NULL, '/notls', 'UNSEEN', NULL, NULL, NULL, NULL, '1', '0', '', '', NULL, NULL, 'BRL', '', 'ORC', 'templates/estimate/default', 'invoices/preview', 'New Estimate #{estimate_id}', '1', '2', 'NotoSans', '1', '0', NULL, NULL, '0', NULL, 'FAT', 'CLI', 'COT', 'UFV', 'SUB', '1022232899186-1k9itl671m7t18t81b6dj7k02m10bms3.apps.googleusercontent.com', '', NULL, '20000', 'Hexagon-3.jpg', '1', '#0081ff', '#ffffff', '#f1f4fa', '#0073e5', '#ffffff', '#0081ff', NULL, NULL, NULL, '0', NULL, NULL, 'center', NULL, NULL, 'left', 'America/Sao_Paulo', '1', '1552676687', NULL, '0', 'YWM0ZmE3MDEtODgzNC00NmJlLWEzNGEtYTE0ZjkyZGUwMGU0', 'b9fad76b-873f-4f47-9d0f-d341c4d222a1', 'R$', 'kWp');


#
# TABLE STRUCTURE FOR: department_has_areas
#

DROP TABLE IF EXISTS department_has_areas;

CREATE TABLE `department_has_areas` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `department_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `description` longtext,
  `orderindex` int(11) DEFAULT '0',
  `public` int(10) DEFAULT NULL,
  `status` enum('active','inactive','deleted') DEFAULT 'active',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO department_has_areas (`id`, `department_id`, `name`, `description`, `orderindex`, `public`, `status`) VALUES ('1', '1', 'Área 1', 'Descrição da área 1', '0', NULL, 'active');


#
# TABLE STRUCTURE FOR: department_has_workers
#

DROP TABLE IF EXISTS department_has_workers;

CREATE TABLE `department_has_workers` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `department_id` int(10) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

INSERT INTO department_has_workers (`id`, `department_id`, `user_id`) VALUES ('1', '1', '1');
INSERT INTO department_has_workers (`id`, `department_id`, `user_id`) VALUES ('7', '1', '2');
INSERT INTO department_has_workers (`id`, `department_id`, `user_id`) VALUES ('9', '2', '1');


#
# TABLE STRUCTURE FOR: departments
#

DROP TABLE IF EXISTS departments;

CREATE TABLE `departments` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `orderindex` int(11) DEFAULT '0',
  `public` int(10) DEFAULT NULL,
  `status` enum('active','inactive','deleted') DEFAULT 'active',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO departments (`id`, `name`, `orderindex`, `public`, `status`) VALUES ('1', 'Engenharia', '0', NULL, 'active');
INSERT INTO departments (`id`, `name`, `orderindex`, `public`, `status`) VALUES ('2', 'Comercial', '1', NULL, 'active');
INSERT INTO departments (`id`, `name`, `orderindex`, `public`, `status`) VALUES ('3', 'Financeiro', '2', NULL, 'active');
INSERT INTO departments (`id`, `name`, `orderindex`, `public`, `status`) VALUES ('4', 'RH', '3', NULL, 'active');
INSERT INTO departments (`id`, `name`, `orderindex`, `public`, `status`) VALUES ('5', 'Pessoal', '0', NULL, 'active');
INSERT INTO departments (`id`, `name`, `orderindex`, `public`, `status`) VALUES ('6', 'Jurídico', '0', NULL, 'active');


#
# TABLE STRUCTURE FOR: events
#

DROP TABLE IF EXISTS events;

CREATE TABLE `events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `allday` varchar(30) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `classname` varchar(255) DEFAULT NULL,
  `start` varchar(255) DEFAULT NULL,
  `end` varchar(255) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT '0',
  `access` varchar(255) DEFAULT NULL,
  `reminder` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO events (`id`, `title`, `description`, `allday`, `url`, `classname`, `start`, `end`, `user_id`, `access`, `reminder`) VALUES ('1', 'Evento teste', 'Evento para testes de alarmes', NULL, NULL, 'bgColor4', '2019-01-04 17:49', '2019-01-11 19:00', '1', NULL, NULL);


#
# TABLE STRUCTURE FOR: lead_has_comments
#

DROP TABLE IF EXISTS lead_has_comments;

CREATE TABLE `lead_has_comments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `attachment` varchar(250) DEFAULT NULL,
  `attachment_link` varchar(250) DEFAULT NULL,
  `datetime` varchar(250) DEFAULT NULL,
  `message` text,
  `user_id` bigint(20) DEFAULT '0',
  `lead_id` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO lead_has_comments (`id`, `attachment`, `attachment_link`, `datetime`, `message`, `user_id`, `lead_id`) VALUES ('1', '', '', '1552067864', 'Andreia, por favor ligue para este cliente', '1', '1');
INSERT INTO lead_has_comments (`id`, `attachment`, `attachment_link`, `datetime`, `message`, `user_id`, `lead_id`) VALUES ('2', '', '', '1552067882', 'Ligou?', '1', '1');
INSERT INTO lead_has_comments (`id`, `attachment`, `attachment_link`, `datetime`, `message`, `user_id`, `lead_id`) VALUES ('3', 'Extrato.ofx', 'a7eabc87bf5cb3afbf154538baf91a63.ofx', '1552067933', 'Olha essa conta de luz', '1', '1');


#
# TABLE STRUCTURE FOR: lead_has_warning_users
#

DROP TABLE IF EXISTS lead_has_warning_users;

CREATE TABLE `lead_has_warning_users` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO lead_has_warning_users (`id`, `lead_id`, `user_id`) VALUES ('1', NULL, '1');
INSERT INTO lead_has_warning_users (`id`, `lead_id`, `user_id`) VALUES ('2', '10', '1');


#
# TABLE STRUCTURE FOR: lead_history
#

DROP TABLE IF EXISTS lead_history;

CREATE TABLE `lead_history` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) DEFAULT NULL,
  `message` text,
  `created_at` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=154 DEFAULT CHARSET=utf8;

INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('1', '5', 'Thiago alterou os seguintes dados de Teste 3: Descrição; ', '2019-03-15 12:16:46');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('2', '5', 'Thiago alterou os seguintes dados de Teste 3: Cliente; Privacidade; Dados de endereço; Dados de contato; ', '2019-03-15 12:17:10');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('3', '5', 'Thiago moveu Teste 3 para Backlog', '2019-03-15 12:17:33');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('4', '5', 'Thiago alterou os seguintes dados de Teste A: Dados de endereço; ', '2019-03-15 12:18:14');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('5', '5', 'Thiago moveu Teste A para Progresso 3', '2019-03-15 12:18:22');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('6', '5', 'Thiago moveu Teste A para Progresso 1', '2019-03-15 12:18:23');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('7', '5', 'Thiago moveu Teste A para Backlog', '2019-03-15 12:18:24');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('8', '5', 'Thiago moveu Teste A para Progresso 3', '2019-03-15 12:18:25');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('9', '5', 'Thiago moveu Teste A para Backlog', '2019-03-15 12:18:26');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('10', '5', 'Thiago moveu Teste A para Progresso 2', '2019-03-15 12:18:41');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('11', '5', 'Thiago moveu Teste A para Backlog', '2019-03-15 12:18:51');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('12', '4', 'Thiago moveu Teste 2 para Backlog', '2019-03-15 16:47:02');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('13', '4', 'Thiago moveu Teste 2 para Progresso 1', '2019-03-15 17:16:55');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('14', '5', 'Thiago moveu Teste A para Progresso 1', '2019-03-15 17:17:03');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('15', '1', 'Thiago moveu Teste 1 para Progresso 3', '2019-03-15 17:17:13');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('16', '4', 'Thiago moveu Teste 2 para Backlog', '2019-03-15 17:17:50');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('17', '4', 'Thiago moveu Teste 2 para Progresso 1', '2019-03-15 17:18:02');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('18', '5', 'Thiago moveu Teste A para Backlog', '2019-03-15 17:18:39');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('19', '4', 'Thiago alterou os seguintes dados de Teste 2: Privacidade; ', '2019-03-15 17:45:24');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('20', '4', 'Thiago moveu Teste 2 para Backlog', '2019-03-15 17:51:23');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('21', '1', 'Thiago moveu Teste 1 para Backlog', '2019-03-15 17:51:24');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('22', '5', 'Thiago moveu Teste A para Progresso 1', '2019-03-15 17:51:29');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('23', '5', 'Thiago moveu Teste A para Ingred', '2019-03-15 17:51:58');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('24', '5', 'Thiago moveu Teste A para Backlog', '2019-03-15 17:52:17');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('25', '1', 'Thiago moveu Teste 1 para Progresso 1', '2019-03-15 17:54:14');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('26', '1', 'Thiago moveu Teste 1 para Backlog', '2019-03-15 17:54:20');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('27', '1', 'Thiago moveu Teste 1 para Progresso 1', '2019-03-15 18:14:07');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('28', '5', 'Thiago moveu Teste A para Progresso 1', '2019-03-15 18:14:17');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('29', '1', 'Thiago moveu Teste 1 para Backlog', '2019-03-15 18:14:19');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('30', '5', 'Thiago moveu Teste A para Backlog', '2019-03-15 18:14:22');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('31', '5', 'Thiago moveu Teste A para Backlog', '2019-03-15 18:14:23');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('32', '1', 'Thiago moveu Teste 1 para Progresso 1', '2019-03-18 10:38:04');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('33', '1', 'Thiago moveu Teste 1 para Progresso 1', '2019-03-18 10:38:07');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('34', '1', 'Thiago moveu Teste 1 para Backlog', '2019-03-18 10:38:10');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('35', '1', 'Thiago moveu Teste 1 para Backlog', '2019-03-18 10:38:12');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('36', '1', 'Thiago moveu Teste 1 para Progresso 1', '2019-03-18 10:38:26');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('37', '1', 'Thiago moveu Teste 1 para Backlog', '2019-03-18 10:38:32');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('38', '1', 'Thiago moveu Teste 1 para Backlog', '2019-03-18 10:38:35');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('39', '1', 'Thiago moveu Teste 1 para Progresso 1', '2019-03-18 10:43:14');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('40', '1', 'Thiago moveu Teste 1 para Backlog', '2019-03-18 10:43:36');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('41', '1', 'Thiago moveu Teste 1 para Progresso 1', '2019-03-18 10:44:19');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('42', '1', 'Thiago moveu Teste 1 para Backlog', '2019-03-18 10:44:38');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('43', '5', 'Thiago moveu Teste A para perdidos', '2019-03-18 10:49:11');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('44', '5', 'Thiago moveu Teste A para Backlog', '2019-03-18 12:33:28');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('45', '6', 'Thiago criou o lead Teste B', '2019-03-18 12:35:18');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('46', '6', 'Thiago moveu Teste B para Progresso 1', '2019-03-18 12:42:35');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('47', '6', 'Thiago moveu Teste B para Progresso 2', '2019-03-18 12:43:18');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('48', '6', 'Thiago moveu Teste B para Progresso 1', '2019-03-18 12:43:27');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('49', '6', 'Thiago moveu Teste B para Backlog', '2019-03-18 12:44:09');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('50', '6', 'Thiago moveu Teste B para Progresso 1', '2019-03-18 12:56:36');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('51', '6', 'Thiago moveu Teste B para Progresso 2', '2019-03-18 12:56:49');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('52', '6', 'Thiago moveu Teste B para Progresso 3', '2019-03-18 12:56:54');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('53', '7', 'Jorge Felipe criou o lead Lead Privado Jorge', '2019-03-18 13:00:54');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('54', '7', 'Thiago moveu Lead Privado Jorge para Progresso 2', '2019-03-19 15:07:22');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('55', '1', 'Thiago moveu Teste 1 para Progresso 1', '2019-03-19 16:28:07');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('56', '1', 'Thiago moveu Teste 1 para Backlog', '2019-03-19 16:28:32');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('57', '1', 'Thiago moveu Teste 1 para Progresso 1', '2019-03-19 16:28:34');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('58', '4', 'Thiago moveu Teste 2 para Progresso 1', '2019-03-19 17:09:10');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('59', '1', 'Thiago moveu Teste 1 para Backlog', '2019-03-19 17:28:32');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('60', '1', 'Thiago moveu Teste 1 para Progresso 1', '2019-03-20 11:43:06');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('61', '1', 'Thiago alterou os seguintes dados de Teste 1: Dados de contato; ', '2019-03-20 11:43:49');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('62', '1', 'Thiago moveu Teste 1 para Progresso 2', '2019-03-20 11:44:03');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('63', '4', 'Thiago moveu Teste 2 para perdidos', '2019-03-20 11:44:57');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('64', '4', 'Thiago moveu Teste 2 para Backlog', '2019-03-20 11:45:12');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('65', '4', 'Thiago moveu Teste 2 para Progresso 2', '2019-03-21 17:31:08');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('66', '5', 'Thiago alterou os seguintes dados de Teste A: Dados de contato; ', '2019-04-01 15:32:03');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('67', '1', 'Thiago moveu Teste 1 para Backlog', '2019-04-03 11:20:10');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('68', '1', 'Thiago alterou os seguintes dados de Teste 1: Privacidade; ', '2019-04-03 11:36:06');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('69', '8', 'Thiago criou o lead Lead com Tags', '2019-04-03 11:41:27');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('70', '8', 'Thiago alterou os seguintes dados de Lead com Tags: Cliente; ', '2019-04-03 11:55:50');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('71', '8', 'Thiago alterou os seguintes dados de Lead com Tags: Dados de endereço; ', '2019-04-03 12:01:20');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('72', '5', 'Thiago alterou os seguintes dados de Teste A: Privacidade; ', '2019-04-03 16:27:20');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('73', '8', 'Thiago moveu Lead com Tags 1, 2, 3, 4, 5, 6, 7, 8, 9 para Progresso 1', '2019-04-05 10:59:22');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('74', '8', 'Thiago moveu Lead com Tags 1, 2, 3, 4, 5, 6, 7, 8, 9 para Backlog', '2019-04-05 11:00:14');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('75', '8', 'Thiago moveu Lead com Tags 1, 2, 3, 4, 5, 6, 7, 8, 9 para Progresso 1', '2019-04-05 11:11:56');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('76', '8', 'Thiago moveu Lead com Tags 1, 2, 3, 4, 5, 6, 7, 8, 9 para Backlog', '2019-04-05 11:12:11');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('77', '8', 'Thiago moveu Lead com Tags 1, 2, 3, 4, 5, 6, 7, 8, 9 para Progresso 1', '2019-04-05 11:12:29');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('78', '8', 'Thiago moveu Lead com Tags 1, 2, 3, 4, 5, 6, 7, 8, 9 para Progresso 1', '2019-04-05 11:21:12');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('79', '8', 'Thiago moveu Lead com Tags 1, 2, 3, 4, 5, 6, 7, 8, 9 para Backlog', '2019-04-05 11:21:13');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('80', '8', 'Thiago moveu Lead com Tags 1, 2, 3, 4, 5, 6, 7, 8, 9 para Progresso 1', '2019-04-05 11:21:28');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('81', '8', 'Thiago moveu Lead com Tags 1, 2, 3, 4, 5, 6, 7, 8, 9 para Backlog', '2019-04-05 11:22:05');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('82', '8', 'Thiago moveu Lead com Tags 1, 2, 3, 4, 5, 6, 7, 8, 9 para Progresso 1', '2019-04-05 11:22:08');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('83', '8', 'Thiago moveu Lead com Tags 1, 2, 3, 4, 5, 6, 7, 8, 9 para Backlog', '2019-04-05 13:41:07');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('84', '8', 'Thiago moveu Lead com Tags 1, 2, 3, 4, 5, 6, 7, 8, 9 para Progresso 1', '2019-04-05 13:41:08');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('85', '8', 'Thiago moveu Lead com Tags 1, 2, 3, 4, 5, 6, 7, 8, 9 para Backlog', '2019-04-05 13:41:12');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('86', '8', 'Thiago moveu Lead com Tags 1, 2, 3, 4, 5, 6, 7, 8, 9 para Progresso 1', '2019-04-05 13:41:42');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('87', '8', 'Thiago moveu Lead com Tags 1, 2, 3, 4, 5, 6, 7, 8, 9 para Backlog', '2019-04-05 13:45:36');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('88', '8', 'Thiago moveu Lead com Tags 1, 2, 3, 4, 5, 6, 7, 8, 9 para Backlog', '2019-04-05 13:45:40');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('89', '8', 'Thiago moveu Lead com Tags 1, 2, 3, 4, 5, 6, 7, 8, 9 para Progresso 1', '2019-04-05 13:45:44');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('90', '8', 'Thiago moveu Lead com Tags 1, 2, 3, 4, 5, 6, 7, 8, 9 para Backlog', '2019-04-05 13:46:08');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('91', '8', 'Thiago moveu Lead com Tags 1, 2, 3, 4, 5, 6, 7, 8, 9 para Progresso 1', '2019-04-05 13:46:16');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('92', '8', 'Thiago moveu Lead com Tags 1, 2, 3, 4, 5, 6, 7, 8, 9 para Backlog', '2019-04-09 10:45:55');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('93', '8', 'Thiago moveu Lead com Tags 1, 2, 3, 4, 5, 6, 7, 8, 9 para Progresso 1', '2019-04-09 10:46:00');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('94', '1', 'Thiago moveu Teste 1 para Progresso 1', '2019-04-15 10:22:03');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('95', '1', 'Thiago moveu Teste 1 para Backlog', '2019-04-15 10:23:31');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('96', '1', 'Thiago moveu Teste 1 para Progresso 1', '2019-04-15 11:34:50');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('97', '1', 'Thiago moveu Teste 1 para Backlog', '2019-04-15 11:34:55');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('98', '1', 'Thiago moveu Teste 1 para Progresso 1', '2019-04-15 11:35:11');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('99', '1', 'Thiago moveu Teste 1 para Progresso 2', '2019-04-15 11:35:23');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('100', '1', 'Thiago moveu Teste 1 para Progresso 3', '2019-04-15 11:35:41');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('101', '1', 'Thiago moveu Teste 1 para Backlog', '2019-04-15 12:18:47');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('102', '1', 'Thiago moveu Teste 1 para Progresso 1', '2019-04-15 12:19:30');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('103', '5', 'Thiago moveu Teste A para Progresso 1', '2019-04-15 13:14:10');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('104', '5', 'Thiago moveu Teste A para Backlog', '2019-04-15 13:14:11');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('105', '5', 'Thiago moveu Teste A para Progresso 1', '2019-04-15 14:08:02');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('106', '5', 'Thiago moveu Teste A para Progresso 2', '2019-04-15 14:08:13');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('107', '5', 'Thiago moveu Teste A para Progresso 3', '2019-04-15 14:08:26');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('108', '6', 'Thiago alterou os seguintes dados de Teste B: Privacidade; Dados de endereço; Dados de contato; ', '2019-04-16 08:45:45');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('109', '9', 'Thiago criou o lead Lead C', '2019-04-16 11:26:54');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('110', '10', 'Thiago criou o lead Lead D', '2019-04-16 11:27:45');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('111', '9', 'Thiago alterou os seguintes dados de Lead C: Dados de endereço; ', '2019-04-16 13:51:11');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('112', '9', 'Thiago alterou os seguintes dados de Lead C: Dados de endereço; ', '2019-04-16 13:51:24');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('113', '9', 'Thiago alterou os seguintes dados de Lead C: Dados de endereço; ', '2019-04-16 13:51:32');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('114', '9', 'Thiago alterou os seguintes dados de Lead C: Dados de endereço; ', '2019-04-16 13:51:55');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('115', '5', 'Thiago alterou os seguintes dados de Teste A: Dados de endereço; ', '2019-04-16 13:54:07');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('116', '5', 'Thiago alterou os seguintes dados de Teste A: Dados de endereço; ', '2019-04-16 13:54:24');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('117', '10', 'Thiago alterou os seguintes dados de Lead D: Dados de endereço; ', '2019-04-16 13:59:44');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('118', '1', 'Thiago alterou os seguintes dados de Teste 1: Dados de endereço; Dados de contato; ', '2019-04-16 14:37:08');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('119', '9', 'Thiago alterou os seguintes dados de Lead C: Dados de endereço; ', '2019-04-17 09:26:55');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('120', '1', 'Thiago alterou os seguintes dados de Teste 1: Descrição; ', '2019-04-29 14:15:46');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('121', '7', 'Jorge Felipe alterou os seguintes dados de Lead Privado Jorge: Privacidade; Dados de endereço; Responsável pelo lead; ', '2019-04-29 14:31:25');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('122', '7', 'Thiago alterou os seguintes dados de Lead Privado Jorge: Responsável pelo lead; ', '2019-04-29 14:31:49');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('123', '5', 'Thiago alterou os seguintes dados de Teste A: Potência nominal; ', '2019-04-29 16:31:44');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('124', '8', 'Thiago alterou os seguintes dados de Lead com Tags 1, 2, 3, 4, 5, 6, 7, 8, 9: Descrição; Dados de endereço; ', '2019-04-29 16:37:04');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('125', '8', 'Thiago moveu Lead com Tags 1, 2, 3, 4, 5, 6, 7, 8, 9 para Progresso 2', '2019-04-29 16:37:12');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('126', '8', 'Thiago moveu Lead com Tags 1, 2, 3, 4, 5, 6, 7, 8, 9 para Progresso 1', '2019-04-29 16:37:16');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('127', '8', 'Thiago moveu Lead com Tags 1, 2, 3, 4, 5, 6, 7, 8, 9 para Progresso 2', '2019-04-29 16:37:58');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('128', '8', 'Thiago alterou os seguintes dados de Lead com Tags 1, 2, 3, 4, 5, 6, 7, 8, 9: Descrição; ', '2019-04-29 16:38:58');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('129', '8', 'Thiago moveu Lead com Tags 1, 2, 3, 4, 5, 6, 7, 8, 9 para Progresso 1', '2019-04-29 16:39:04');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('130', '8', 'Thiago alterou os seguintes dados de Lead com Tags 1, 2, 3, 4, 5, 6, 7, 8, 9: Descrição; ', '2019-04-29 16:39:33');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('131', '8', 'Thiago moveu Lead com Tags 1, 2, 3, 4, 5, 6, 7, 8, 9 para Progresso 2', '2019-04-29 16:39:41');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('132', '5', 'Thiago moveu Teste A para Estágio 5', '2019-04-29 16:52:52');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('133', '8', 'Thiago moveu Lead com Tags 1, 2, 3, 4, 5, 6, 7, 8, 9 para Estágio 6', '2019-04-29 16:52:53');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('134', '9', 'Thiago moveu Lead CD para Progresso 1', '2019-06-24 18:03:54');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('135', '9', 'Thiago moveu Lead CD para Backlog', '2019-06-24 18:03:58');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('136', '9', 'Thiago moveu Lead CD para perdidos', '2019-06-24 18:04:10');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('137', '9', 'Thiago moveu Lead CD para Backlog', '2019-06-24 18:04:22');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('138', '11', 'Thiago criou o lead Lead YZ', '2019-07-08 15:08:42');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('139', '10', 'Thiago alterou os seguintes dados de Lead D: Dado do lead; ', '2019-07-10 13:53:49');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('140', '10', 'Thiago alterou os seguintes dados de Lead D: Dado do lead; ', '2019-07-10 13:53:57');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('141', '10', 'Thiago alterou os seguintes dados de Lead D: Dado do lead; ', '2019-07-10 14:05:55');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('142', '10', 'Thiago alterou os seguintes dados de Lead D: Dado do lead; ', '2019-07-10 14:06:05');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('143', '10', 'Thiago alterou os seguintes dados de Lead D: Dado do lead; ', '2019-07-10 14:08:18');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('144', '10', 'Thiago alterou os seguintes dados de Lead D: Valor da proposta; ', '2019-08-12 16:23:50');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('145', '10', 'Thiago alterou os seguintes dados de Lead D: Dados de endereço; Dados de contato; ', '2019-08-12 16:24:04');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('146', '10', 'Thiago alterou os seguintes dados de Thiago Pires Alves de Castro: Potência nominal; ', '2019-08-12 16:24:22');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('147', '10', 'Thiago moveu Thiago Pires Alves de Castro para Progresso 1', '2019-08-13 09:13:05');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('148', '11', 'Thiago moveu Lead YZ para Progresso 1', '2019-08-13 09:13:05');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('149', '9', 'Thiago moveu Lead CD para Progresso 1', '2019-08-13 09:13:06');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('150', '7', 'Thiago moveu Lead Privado Jorge para Progresso 1', '2019-08-13 09:13:07');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('151', '4', 'Thiago moveu Teste 2 para Progresso 1', '2019-08-13 09:13:08');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('152', '5', 'Thiago moveu Teste A para Progresso 1', '2019-08-13 09:13:13');
INSERT INTO lead_history (`id`, `lead_id`, `message`, `created_at`) VALUES ('153', '8', 'Thiago moveu Lead com Tags 1, 2, 3, 4, 5, 6, 7, 8, 9 para Progresso 1', '2019-08-13 09:13:18');


#
# TABLE STRUCTURE FOR: lead_status
#

DROP TABLE IF EXISTS lead_status;

CREATE TABLE `lead_status` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `description` text,
  `order` float DEFAULT '0',
  `offset` bigint(200) DEFAULT '0',
  `limit` bigint(200) DEFAULT '50',
  `color` varchar(100) DEFAULT '#5071ab',
  `duration` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

INSERT INTO lead_status (`id`, `name`, `description`, `order`, `offset`, `limit`, `color`, `duration`) VALUES ('12', 'Backlog', '', '1', '0', '50', 'orangered', '0');
INSERT INTO lead_status (`id`, `name`, `description`, `order`, `offset`, `limit`, `color`, `duration`) VALUES ('13', 'Progresso 1', '', '2', '0', '50', '#1261cb', '2');
INSERT INTO lead_status (`id`, `name`, `description`, `order`, `offset`, `limit`, `color`, `duration`) VALUES ('14', 'Progresso 2', '', '3', '0', '50', '#1261cb', '1');
INSERT INTO lead_status (`id`, `name`, `description`, `order`, `offset`, `limit`, `color`, `duration`) VALUES ('15', 'Progresso 3', '', '4', '0', '50', '#1261cb', '15');
INSERT INTO lead_status (`id`, `name`, `description`, `order`, `offset`, `limit`, `color`, `duration`) VALUES ('16', 'Estágio 4', '', '5', '0', '50', '#1261cb', '1');
INSERT INTO lead_status (`id`, `name`, `description`, `order`, `offset`, `limit`, `color`, `duration`) VALUES ('17', 'Estágio 5', '', '6', '0', '50', '#1261cb', '1');
INSERT INTO lead_status (`id`, `name`, `description`, `order`, `offset`, `limit`, `color`, `duration`) VALUES ('18', 'Estágio 6', '', '7', '0', '50', '#1261cb', '4');


#
# TABLE STRUCTURE FOR: lead_status_has_receivers
#

DROP TABLE IF EXISTS lead_status_has_receivers;

CREATE TABLE `lead_status_has_receivers` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `lead_status_id` int(10) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO lead_status_has_receivers (`id`, `lead_status_id`, `user_id`) VALUES ('5', '14', '1');
INSERT INTO lead_status_has_receivers (`id`, `lead_status_id`, `user_id`) VALUES ('10', '13', '1');


#
# TABLE STRUCTURE FOR: leads
#

DROP TABLE IF EXISTS leads;

CREATE TABLE `leads` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status_id` bigint(20) DEFAULT '0',
  `source` varchar(250) DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `position` varchar(250) DEFAULT NULL,
  `address` varchar(250) DEFAULT NULL,
  `city` varchar(250) DEFAULT NULL,
  `state` varchar(250) DEFAULT NULL,
  `country` varchar(250) DEFAULT NULL,
  `zipcode` varchar(250) DEFAULT NULL,
  `language` varchar(250) DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `owner` varchar(500) DEFAULT NULL,
  `phone` varchar(250) DEFAULT NULL,
  `mobile` varchar(250) DEFAULT NULL,
  `company` varchar(250) DEFAULT NULL,
  `tags` varchar(10000) NOT NULL,
  `description` text,
  `proposal_value` varchar(20) DEFAULT '0,00',
  `rated_power_mod` varchar(10) NOT NULL,
  `last_contact` varchar(250) DEFAULT NULL,
  `last_landing` varchar(250) DEFAULT NULL COMMENT 'Controla a última aterrisagem do Lead no lead_status atual',
  `created` varchar(20) DEFAULT NULL,
  `modified` varchar(20) DEFAULT NULL,
  `private` tinyint(1) DEFAULT '1',
  `completed` varchar(255) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT '0',
  `icon` varchar(255) DEFAULT NULL,
  `order` float DEFAULT '0',
  `payment` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO leads (`id`, `status_id`, `source`, `name`, `position`, `address`, `city`, `state`, `country`, `zipcode`, `language`, `email`, `owner`, `phone`, `mobile`, `company`, `tags`, `description`, `proposal_value`, `rated_power_mod`, `last_contact`, `last_landing`, `created`, `modified`, `private`, `completed`, `user_id`, `icon`, `order`, `payment`) VALUES ('1', '13', '', 'Teste 1', 'Diretor', '', '', '', 'Brasil', '', NULL, 'thiagopac@gmail.com', 'José Bonifácio', '', '', 'Cliente Exemplo', 'Rural,Urbano,Comercial', 'Fiz contato com o cliente', '', '540.00', NULL, '2019-04-29 14:15', '2019-03-17 08:14', '2019-04-29 14:15', '0', NULL, '1', NULL, '14.9', '');
INSERT INTO leads (`id`, `status_id`, `source`, `name`, `position`, `address`, `city`, `state`, `country`, `zipcode`, `language`, `email`, `owner`, `phone`, `mobile`, `company`, `tags`, `description`, `proposal_value`, `rated_power_mod`, `last_contact`, `last_landing`, `created`, `modified`, `private`, `completed`, `user_id`, `icon`, `order`, `payment`) VALUES ('4', '13', '', 'Teste 2', 'Diretor', 'Rua do Cliente 2, 100', 'Cidade Teste 2', 'MG', 'Brasil', '10020200', NULL, 'diretor@cliente2.com', 'Dono do Teste 2', '31333334444', '31988884845', 'Cliente Teste 2', 'Urbano,Comercial', '									Descrição do Teste 2						', NULL, '', NULL, '2019-08-13 09:13', '2019-03-13 16:53', '2019-03-20 11:46', '1', NULL, '2', NULL, '14.9', '');
INSERT INTO leads (`id`, `status_id`, `source`, `name`, `position`, `address`, `city`, `state`, `country`, `zipcode`, `language`, `email`, `owner`, `phone`, `mobile`, `company`, `tags`, `description`, `proposal_value`, `rated_power_mod`, `last_contact`, `last_landing`, `created`, `modified`, `private`, `completed`, `user_id`, `icon`, `order`, `payment`) VALUES ('5', '13', '', 'Teste A', 'Diretor', 'Rua Teste 3, 30', 'Cidade Teste 3', 'SP', 'Brasil', '30010-300', NULL, 'diretor@teste3.com', 'Dono Teste 3', '(31)3333-4444', '(31)98888-6463', 'Cliente Teste 3', 'Comercial', '																																																																																																																																																																					Descrição do Cliente 3																																																																										', '50.000,00', '1000.00', NULL, '2019-08-13 09:13', '2019-03-14 15:53', '2019-04-29 16:31', '0', NULL, '1', NULL, '14.8', '');
INSERT INTO leads (`id`, `status_id`, `source`, `name`, `position`, `address`, `city`, `state`, `country`, `zipcode`, `language`, `email`, `owner`, `phone`, `mobile`, `company`, `tags`, `description`, `proposal_value`, `rated_power_mod`, `last_contact`, `last_landing`, `created`, `modified`, `private`, `completed`, `user_id`, `icon`, `order`, `payment`) VALUES ('6', '15', NULL, 'Teste B', 'Função Teste', 'Rua Teste B', 'Belo Horizonte', 'MG', 'Brasil', '31300-200', NULL, 'teste@clienteb.com.br', 'Thiago Pires', '(33)3322-22', '(98)88888-88', 'Cliente Teste B', 'Urbano', '			Projeto de teste B		', '', '', NULL, '2019-04-16 08:45', '2019-03-18 12:35', '2019-04-16 08:45', '0', NULL, '1', NULL, '15', '');
INSERT INTO leads (`id`, `status_id`, `source`, `name`, `position`, `address`, `city`, `state`, `country`, `zipcode`, `language`, `email`, `owner`, `phone`, `mobile`, `company`, `tags`, `description`, `proposal_value`, `rated_power_mod`, `last_contact`, `last_landing`, `created`, `modified`, `private`, `completed`, `user_id`, `icon`, `order`, `payment`) VALUES ('7', '13', NULL, 'Lead Privado Jorge', '', '', '', '', 'Brasil', '', NULL, '', '', '', '', '', 'Comercial', '															', '', '', NULL, '2019-08-13 09:13', '2019-03-18 13:00', '2019-04-29 14:31', '0', NULL, '2', NULL, '15', '');
INSERT INTO leads (`id`, `status_id`, `source`, `name`, `position`, `address`, `city`, `state`, `country`, `zipcode`, `language`, `email`, `owner`, `phone`, `mobile`, `company`, `tags`, `description`, `proposal_value`, `rated_power_mod`, `last_contact`, `last_landing`, `created`, `modified`, `private`, `completed`, `user_id`, `icon`, `order`, `payment`) VALUES ('8', '13', NULL, 'Lead com Tags 1, 2, 3, 4, 5, 6, 7, 8, 9', '', '', 'Belo Horizonte', 'MG', 'Brasil', '', NULL, '', '', '', '', 'Nome do Cliente', 'Urbano,Industrial', '', '85.900,00', '', NULL, '2019-08-13 09:13', '2019-04-03 11:41', '2019-04-29 16:39', '0', NULL, '1', NULL, '14.9', '');
INSERT INTO leads (`id`, `status_id`, `source`, `name`, `position`, `address`, `city`, `state`, `country`, `zipcode`, `language`, `email`, `owner`, `phone`, `mobile`, `company`, `tags`, `description`, `proposal_value`, `rated_power_mod`, `last_contact`, `last_landing`, `created`, `modified`, `private`, `completed`, `user_id`, `icon`, `order`, `payment`) VALUES ('9', '13', NULL, 'Lead CD', 'Função C', '', '', 'CE', 'Brasil', '', NULL, '', '', '', '', 'Cliente C', 'Urbano', '																																																																																																																																																																', '', '', NULL, '2019-08-13 09:13', '2019-04-16 11:26', '2019-06-24 18:04', '0', NULL, '1', NULL, '14.9', 'bank financing');
INSERT INTO leads (`id`, `status_id`, `source`, `name`, `position`, `address`, `city`, `state`, `country`, `zipcode`, `language`, `email`, `owner`, `phone`, `mobile`, `company`, `tags`, `description`, `proposal_value`, `rated_power_mod`, `last_contact`, `last_landing`, `created`, `modified`, `private`, `completed`, `user_id`, `icon`, `order`, `payment`) VALUES ('10', '13', NULL, 'Thiago Pires Alves de Castro', 'Função D', 'Rua Araguari, 1156', 'Belo Horizonte', 'MG', 'Brasil', '30190-111', NULL, 'thiagopac@gmail.com', 'Teste', '(31)9888-86063', '', 'Cliente D', 'Urbano', '																																																												', '1.000.000,00', '354.03', NULL, '2019-08-13 09:13', '2019-04-16 11:27', '2019-08-12 16:24', '0', NULL, '1', NULL, '15', '');
INSERT INTO leads (`id`, `status_id`, `source`, `name`, `position`, `address`, `city`, `state`, `country`, `zipcode`, `language`, `email`, `owner`, `phone`, `mobile`, `company`, `tags`, `description`, `proposal_value`, `rated_power_mod`, `last_contact`, `last_landing`, `created`, `modified`, `private`, `completed`, `user_id`, `icon`, `order`, `payment`) VALUES ('11', '13', NULL, 'Lead YZ', '', '', '', '', 'Brasil', '', NULL, '', '', '', '', '', '', '					', '', '', NULL, '2019-08-13 09:13', '2019-07-08 15:08', '2019-07-08 15:08', '0', NULL, '1', NULL, '15', '');


#
# TABLE STRUCTURE FOR: messages
#

DROP TABLE IF EXISTS messages;

CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT '0',
  `media_id` int(11) DEFAULT '0',
  `from` varchar(120) DEFAULT NULL,
  `text` text,
  `datetime` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: modules
#

DROP TABLE IF EXISTS modules;

CREATE TABLE `modules` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `link` varchar(250) DEFAULT NULL,
  `type` varchar(250) DEFAULT NULL,
  `icon` varchar(150) DEFAULT NULL,
  `sort` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8;

INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('1', 'Dashboard', 'dashboard', 'main', 'icon dripicons-meter', '1');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('2', 'Messages', 'messages', 'main', 'icon dripicons-message', '2');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('3', 'Projects', 'projects', 'main', 'icon dripicons-briefcase', '3');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('4', 'Clients', 'clients', 'main', 'icon dripicons-user', '4');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('5', 'Invoices', 'invoices', 'main', 'icon dripicons-document', '5');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('6', 'Items', 'items', 'main', 'icon dripicons-shopping-bag', '7');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('7', 'Quotations', 'quotations', 'main', 'icon dripicons-blog', '8');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('8', 'Subscriptions', 'subscriptions', 'main', 'icon dripicons-retweet', '6');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('9', 'Settings', 'settings', 'main', 'icon dripicons-gear', '20');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('10', 'QuickAccess', 'quickaccess', 'widget', '', '50');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('11', 'User Online', 'useronline', 'widget', '', '51');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('12', 'Estimates', 'estimates', 'main', 'icon dripicons-document-edit', '5');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('13', 'Expenses', 'expenses', 'main', 'icon dripicons-cart', '5');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('20', 'Calendar', 'calendar', 'main', 'icon dripicons-calendar', '8');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('33', 'Reports', 'reports', 'main', 'icon dripicons-graph-pie', '8');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('34', 'Parameterization', 'parameterization', 'main', 'icon dripicons-list', '5');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('101', 'Projects', 'cprojects', 'client', 'icon dripicons-rocket', '2');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('102', 'Invoices', 'cinvoices', 'client', 'icon dripicons-document', '3');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('103', 'Messages', 'cmessages', 'client', 'icon dripicons-message', '1');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('104', 'Subscriptions', 'csubscriptions', 'client', 'icon dripicons-retweet', '4');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('105', 'Tickets', 'tickets', 'main', 'icon dripicons-ticket', '8');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('106', 'Tickets', 'ctickets', 'client', 'icon dripicons-ticket', '4');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('107', 'Estimates', 'cestimates', 'client', 'icon dripicons-document-edit', '3');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('108', 'Leads', 'leads', 'main', 'icon dripicons-experiment', '4');


#
# TABLE STRUCTURE FOR: notifications
#

DROP TABLE IF EXISTS notifications;

CREATE TABLE `notifications` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) DEFAULT NULL,
  `message` text,
  `created_at` varchar(50) DEFAULT NULL,
  `url` varchar(500) DEFAULT NULL,
  `status` enum('new','read') DEFAULT 'new',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

INSERT INTO notifications (`id`, `user_id`, `message`, `created_at`, `url`, `status`) VALUES ('1', '1', '<p><b>Thiago</b> efetuou uma alteração em um ticket atribuído a você. </p>[Projeto 1]', '2019-05-06 11:45:14', 'http://localhost/zenit/projects/view/1', 'read');
INSERT INTO notifications (`id`, `user_id`, `message`, `created_at`, `url`, `status`) VALUES ('2', '1', '<p><b>Thiago</b> efetuou uma alteração em um ticket atribuído a você. </p>[Projeto 1]', '2019-05-06 11:45:36', 'http://localhost/zenit/projects/view/1', 'read');
INSERT INTO notifications (`id`, `user_id`, `message`, `created_at`, `url`, `status`) VALUES ('3', '2', '<p><b>Thiago</b> efetuou uma alteração em um ticket atribuído a você. </p>[Projeto 1]', '2019-05-06 11:46:06', 'http://localhost/zenit/projects/view/1', 'new');
INSERT INTO notifications (`id`, `user_id`, `message`, `created_at`, `url`, `status`) VALUES ('4', '1', '<p><b>Thiago</b> efetuou uma alteração em um ticket atribuído a você. </p>[Projeto 1]', '2019-05-06 11:48:38', 'http://localhost/zenit/projects/view/1', 'read');
INSERT INTO notifications (`id`, `user_id`, `message`, `created_at`, `url`, `status`) VALUES ('5', '1', '<b>Thiago</b> moveu <b>Lead CD</b> para <b>Progresso 1</b>', '2019-06-24 18:03:54', 'http://localhost/zenit/leads/', 'read');
INSERT INTO notifications (`id`, `user_id`, `message`, `created_at`, `url`, `status`) VALUES ('6', '1', '<p><b>Thiago</b> concluiu a tarefa  <b>Tarefa 1</b> e você já pode iniciar a tarefa <b>Tarefa 2</b> </p>[Projeto 2]', '2019-07-01 11:41:54', 'http://localhost/zenit/projects/view/2', 'read');
INSERT INTO notifications (`id`, `user_id`, `message`, `created_at`, `url`, `status`) VALUES ('7', '2', '<p><b>Thiago</b> concluiu a tarefa  <b>Tarefa 2</b> e você já pode iniciar a tarefa <b>Tarefa 3</b> </p>[Projeto 2]', '2019-07-01 11:41:58', 'http://localhost/zenit/projects/view/2', 'new');
INSERT INTO notifications (`id`, `user_id`, `message`, `created_at`, `url`, `status`) VALUES ('8', '1', '<p><b>Thiago</b> concluiu a tarefa  <b>Tarefa 1</b> e você já pode iniciar a tarefa <b>Tarefa 2</b> </p>[Projeto 2]', '2019-07-01 11:42:02', 'http://localhost/zenit/projects/view/2', 'read');
INSERT INTO notifications (`id`, `user_id`, `message`, `created_at`, `url`, `status`) VALUES ('9', '1', '<p><b>Thiago</b> concluiu a tarefa  <b>Tarefa 3</b> e você já pode iniciar a tarefa <b>Tarefa 4</b> </p>[Projeto 2]', '2019-07-01 11:42:04', 'http://localhost/zenit/projects/view/2', 'read');
INSERT INTO notifications (`id`, `user_id`, `message`, `created_at`, `url`, `status`) VALUES ('10', '1', '<p><b>Thiago</b> concluiu a tarefa  <b>Tarefa 1</b> e você já pode iniciar a tarefa <b>Tarefa 2</b> </p>[Projeto 2]', '2019-07-01 11:42:12', 'http://localhost/zenit/projects/view/2', 'read');
INSERT INTO notifications (`id`, `user_id`, `message`, `created_at`, `url`, `status`) VALUES ('11', '1', '<b>Thiago</b> moveu <b>Thiago Pires Alves de Castro</b> para <b>Progresso 1</b>', '2019-08-13 09:13:05', 'http://localhost/zenit/leads/', 'new');
INSERT INTO notifications (`id`, `user_id`, `message`, `created_at`, `url`, `status`) VALUES ('12', '1', '<b>Thiago</b> moveu <b>Thiago Pires Alves de Castro</b> para <b>Progresso 1</b>', '2019-08-13 09:13:05', 'http://localhost/zenit/leads/', 'new');
INSERT INTO notifications (`id`, `user_id`, `message`, `created_at`, `url`, `status`) VALUES ('13', '1', '<b>Thiago</b> moveu <b>Lead YZ</b> para <b>Progresso 1</b>', '2019-08-13 09:13:05', 'http://localhost/zenit/leads/', 'new');
INSERT INTO notifications (`id`, `user_id`, `message`, `created_at`, `url`, `status`) VALUES ('14', '1', '<b>Thiago</b> moveu <b>Lead CD</b> para <b>Progresso 1</b>', '2019-08-13 09:13:06', 'http://localhost/zenit/leads/', 'new');
INSERT INTO notifications (`id`, `user_id`, `message`, `created_at`, `url`, `status`) VALUES ('15', '1', '<b>Thiago</b> moveu <b>Lead Privado Jorge</b> para <b>Progresso 1</b>', '2019-08-13 09:13:07', 'http://localhost/zenit/leads/', 'new');
INSERT INTO notifications (`id`, `user_id`, `message`, `created_at`, `url`, `status`) VALUES ('16', '1', '<b>Thiago</b> moveu <b>Teste 2</b> para <b>Progresso 1</b>', '2019-08-13 09:13:08', 'http://localhost/zenit/leads/', 'new');
INSERT INTO notifications (`id`, `user_id`, `message`, `created_at`, `url`, `status`) VALUES ('17', '1', '<b>Thiago</b> moveu <b>Teste A</b> para <b>Progresso 1</b>', '2019-08-13 09:13:13', 'http://localhost/zenit/leads/', 'new');
INSERT INTO notifications (`id`, `user_id`, `message`, `created_at`, `url`, `status`) VALUES ('18', '1', '<b>Thiago</b> moveu <b>Lead com Tags 1, 2, 3, 4, 5, 6, 7, 8, 9</b> para <b>Progresso 1</b>', '2019-08-13 09:13:18', 'http://localhost/zenit/leads/', 'new');


#
# TABLE STRUCTURE FOR: privatemessages
#

DROP TABLE IF EXISTS privatemessages;

CREATE TABLE `privatemessages` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(150) DEFAULT NULL,
  `sender` varchar(250) DEFAULT NULL,
  `recipient` varchar(250) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `message` text,
  `time` varchar(100) DEFAULT NULL,
  `conversation` varchar(32) DEFAULT NULL,
  `deleted` int(11) DEFAULT '0',
  `attachment` varchar(255) DEFAULT NULL,
  `attachment_link` varchar(255) DEFAULT NULL,
  `receiver_delete` int(11) DEFAULT '0',
  `marked` int(1) DEFAULT '0',
  `read` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;

INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('1', 'deleted', 'u2', 'u1', 'Teste 1', '<p>Teste 1</p>', '2018-12-14 16:17', '2b87ff0ff14394bf0998ccaaf3598aaa', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('2', 'Replied', 'u1', 'u2', 'Teste 2', '<p>Teste 1 resposta</p>', '2018-12-14 18:02', '2b87ff0ff14394bf0998ccaaf3598aaa', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('3', 'Read', 'u1', 'u2', 'Teste 3', '<p>Enviando mensagem</p>', '2018-12-17 12:20', '45c214dc9471a7423bf1f799c303f642', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('4', 'Read', 'u1', 'u2', 'Teste 2', '<p>Teste 1 resposta 2</p>', '2018-12-17 14:32', '2b87ff0ff14394bf0998ccaaf3598aaa', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('5', 'Replied', 'u2', 'u1', 'Teste 4', '<p>Inciando teste 4</p>', '2018-12-17 14:53', 'd7419af0b19181a8dc036951f55e9622', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('6', 'deleted', 'u1', 'c2', 'Teste 5', '<p>Mensagem do teste 5</p>', '2018-12-20 10:33', '06bc463fd05c4370bcc2db95edd5ae08', '1', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('7', 'Read', 'c2', 'u1', 'Teste 6', '<p>Mensagem teste 6</p>', '2018-12-20 10:33', '31a4df11173f6e44981c07a66ec13656', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('8', 'Read', 'u1', 'u2', 'Teste 4', '<p>jubileu</p>', '2019-02-14 09:57', 'd7419af0b19181a8dc036951f55e9622', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('9', 'Read', 'u1', 'u2', 'teste 2', '<p>teste 2</p>', '2019-06-14 16:20', '0ac43de1f7c57799cf9ad8407d29d68e', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('10', 'Read', 'u1', 'u2', 'teste 3', '<p>teste 3<br></p>', '2019-06-14 16:20', 'f7b523054461c1e5794f2001e7459a21', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('11', 'Read', 'u1', 'u2', 'teste 4', '<p>teste 4<br></p>', '2019-06-14 16:20', '295ca52f9d1df57a8d011f505e2ddb96', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('12', 'Read', 'u1', 'u2', 'teste 5', '<p>teste 5<br></p>', '2019-06-14 16:20', 'f29897de3a77750ab546aee8eda6dc7b', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('13', 'Read', 'u1', 'u2', 'teste 6', '<p>teste 6<br></p>', '2019-06-14 16:20', '3e5f547e811db36d92b298000d900c92', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('14', 'Read', 'u1', 'u2', 'teste 7', '<p>teste 7<br></p>', '2019-06-14 16:21', '21efae8c9a6fe571f6f8ed8be52fb30f', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('15', 'Read', 'u1', 'u2', 'teste 8', '<p>teste 8<br></p>', '2019-06-14 16:21', 'e88b6956d03c67fac4fa1a2381e6c012', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('16', 'Read', 'u1', 'u2', 'teste 9', '<p>teste 9<br></p>', '2019-06-14 16:21', '877cafe0cce727e7e66c2f713a0e58a4', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('17', 'Read', 'u1', 'u2', 'teste 10', '<p>teste 10<br></p>', '2019-06-14 16:21', '36caa270e942d4766207180b5692174c', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('18', 'Read', 'u1', 'u2', 'teste 11', '<p>teste 11<br></p>', '2019-06-14 16:21', '42651a0866358fc8f45c68e8487cce03', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('19', 'Read', 'u1', 'u2', 'teste 12', '<p>teste 12<br></p>', '2019-06-14 16:21', 'aa03fdc5b4bdd10668020e130defa6f7', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('20', 'Read', 'u1', 'u2', 'teste 13', '<p>teste 13<br></p>', '2019-06-14 16:21', '3a06531bf7a93f0d06a53fe3528f4a6d', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('21', 'Read', 'u1', 'u2', 'teste 14', '<p>teste 14<br></p>', '2019-06-14 16:22', 'd305ebfb0f29613b0acbacd1ce2ceb48', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('22', 'Read', 'u1', 'u2', 'teste 15', '<p>teste 15<br></p>', '2019-06-14 16:22', 'b5c131033df9cc2432759af9f0e65c4e', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('23', 'Read', 'u1', 'u2', 'teste 16', '<p>teste 16<br></p>', '2019-06-14 16:22', '1ab09854b22bf8fd8ebc9344aef03faa', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('24', 'Read', 'u1', 'u2', 'teste 17', '<p>teste 17<br></p>', '2019-06-14 16:22', '542fde5d657bc1f64744563d3f978908', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('25', 'Read', 'u1', 'u2', 'teste 18', '<p>teste 18<br></p>', '2019-06-14 16:22', '10caf96bfa10860eb27d992037b38d27', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('26', 'Read', 'u1', 'u2', 'teste 19', '<p>teste 19<br></p>', '2019-06-14 16:22', '4d83591f7f40057fd3777bd6d9f1c685', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('27', 'Read', 'u1', 'u2', 'teste 20', '<p>teste 20<br></p>', '2019-06-14 16:22', 'cc658886c16b78b459e61f874047e075', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('28', 'Read', 'u1', 'u2', 'teste 21', '<p>teste 21<br></p>', '2019-06-14 16:22', '76ae984d6fec7be1a71b3523862b2712', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('29', 'Read', 'u1', 'u2', 'teste 22', '<p>teste 22<br></p>', '2019-06-14 16:22', '3fd7d7239a00a9d8030d72d7837edacc', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('30', 'Read', 'u1', 'u2', 'teste 23', '<p>teste 23<br></p>', '2019-06-14 16:23', 'cf4ab3414b48287d81fa8fb5bf7c00c9', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('31', 'Read', 'u1', 'u2', 'teste 24', '<p>teste 24<br></p>', '2019-06-14 16:23', '7d379911a508ba379a08c0b56ae11b07', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('32', 'Read', 'u1', 'u2', 'teste 25', '<p>teste 25<br></p>', '2019-06-14 16:23', 'a6103477f62b08c34577ea07967aa5f3', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('33', 'Read', 'u1', 'u2', 'teste 26', '<p>teste 26<br></p>', '2019-06-14 16:23', 'e4fd6e43f6ba197ebdc08f2106cd28af', '0', NULL, NULL, '0', '0', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`, `marked`, `read`) VALUES ('34', 'Read', 'u1', 'u2', 'teste 27', '<p>teste 27<br></p>', '2019-06-14 16:23', 'aecc05e78f7ee75903cc4043750c3bc1', '0', NULL, NULL, '0', '0', '0');


#
# TABLE STRUCTURE FOR: project_has_activities
#

DROP TABLE IF EXISTS project_has_activities;

CREATE TABLE `project_has_activities` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `project_id` bigint(20) DEFAULT '0',
  `user_id` bigint(20) DEFAULT '0',
  `client_id` bigint(20) DEFAULT '0',
  `datetime` varchar(250) DEFAULT NULL,
  `subject` varchar(250) DEFAULT NULL,
  `message` text,
  `type` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: project_has_files
#

DROP TABLE IF EXISTS project_has_files;

CREATE TABLE `project_has_files` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `project_id` int(10) DEFAULT '0',
  `user_id` int(10) DEFAULT '0',
  `client_id` int(10) DEFAULT '0',
  `type` varchar(80) DEFAULT NULL,
  `name` varchar(120) DEFAULT NULL,
  `filename` varchar(150) DEFAULT NULL,
  `description` text,
  `savename` varchar(200) DEFAULT NULL,
  `phase` varchar(100) DEFAULT NULL,
  `date` varchar(50) DEFAULT NULL,
  `download_counter` int(10) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: project_has_milestones
#

DROP TABLE IF EXISTS project_has_milestones;

CREATE TABLE `project_has_milestones` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `description` longtext,
  `due_date` varchar(255) DEFAULT NULL,
  `orderindex` int(11) DEFAULT '0',
  `start_date` varchar(255) DEFAULT NULL,
  `area_id` int(11) DEFAULT '0',
  `area_order` int(11) DEFAULT '0',
  `public` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO project_has_milestones (`id`, `project_id`, `name`, `description`, `due_date`, `orderindex`, `start_date`, `area_id`, `area_order`, `public`) VALUES ('1', '1', 'Pacote 1', '', NULL, '0', NULL, '1', '0', NULL);
INSERT INTO project_has_milestones (`id`, `project_id`, `name`, `description`, `due_date`, `orderindex`, `start_date`, `area_id`, `area_order`, `public`) VALUES ('2', '2', 'Pacote 1', '', NULL, '0', NULL, '1', '0', NULL);
INSERT INTO project_has_milestones (`id`, `project_id`, `name`, `description`, `due_date`, `orderindex`, `start_date`, `area_id`, `area_order`, `public`) VALUES ('3', '2', 'Pacote 2', '', NULL, '0', NULL, '1', '0', NULL);
INSERT INTO project_has_milestones (`id`, `project_id`, `name`, `description`, `due_date`, `orderindex`, `start_date`, `area_id`, `area_order`, `public`) VALUES ('4', '2', 'Pacote 3', '', NULL, '0', NULL, '1', '0', '0');
INSERT INTO project_has_milestones (`id`, `project_id`, `name`, `description`, `due_date`, `orderindex`, `start_date`, `area_id`, `area_order`, `public`) VALUES ('5', '2', 'Pacote 4', '', NULL, '0', NULL, '1', '0', '0');
INSERT INTO project_has_milestones (`id`, `project_id`, `name`, `description`, `due_date`, `orderindex`, `start_date`, `area_id`, `area_order`, `public`) VALUES ('6', '2', 'Pacote 5', '', NULL, '0', NULL, '1', '0', '0');
INSERT INTO project_has_milestones (`id`, `project_id`, `name`, `description`, `due_date`, `orderindex`, `start_date`, `area_id`, `area_order`, `public`) VALUES ('7', '2', 'Pacote 6', '', NULL, '0', NULL, '1', '0', '0');
INSERT INTO project_has_milestones (`id`, `project_id`, `name`, `description`, `due_date`, `orderindex`, `start_date`, `area_id`, `area_order`, `public`) VALUES ('8', '2', 'Pacote 7', '', NULL, '0', NULL, '1', '0', '0');


#
# TABLE STRUCTURE FOR: project_has_tasks
#

DROP TABLE IF EXISTS project_has_tasks;

CREATE TABLE `project_has_tasks` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `project_id` int(10) DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `public` int(10) DEFAULT NULL,
  `datetime` int(11) DEFAULT NULL,
  `description` text,
  `start_date` varchar(250) DEFAULT NULL,
  `due_date` varchar(250) DEFAULT NULL,
  `completion_date` varchar(250) DEFAULT NULL,
  `value` float DEFAULT '0',
  `priority` smallint(6) DEFAULT '0',
  `time` int(11) DEFAULT NULL,
  `client_id` int(30) DEFAULT '0',
  `created_by_client` int(30) DEFAULT '0',
  `tracking` int(11) DEFAULT '0',
  `time_spent` int(11) DEFAULT '0',
  `milestone_id` int(11) DEFAULT '0',
  `invoice_id` int(60) DEFAULT '0',
  `milestone_order` int(11) DEFAULT '0',
  `task_order` int(11) DEFAULT '0',
  `progress` int(11) DEFAULT '0',
  `created_at` varchar(50) DEFAULT NULL,
  `sucessors` varchar(10000) DEFAULT NULL COMMENT 'Array de IDs de tarefas sucessoras',
  `scheduled_time` int(11) NOT NULL DEFAULT '0',
  `reference` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `description`, `start_date`, `due_date`, `completion_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `sucessors`, `scheduled_time`, `reference`) VALUES ('1', '1', 'Tarefa 1', '1', 'open', '0', NULL, '', '2019-05-06 12:00', '2019-05-08 12:00', NULL, '0', '2', NULL, '0', '0', '0', '0', '1', '0', '0', '0', '0', '2019-05-06 11:45:14', '2', '3', 'PJFZLCS757');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `description`, `start_date`, `due_date`, `completion_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `sucessors`, `scheduled_time`, `reference`) VALUES ('2', '1', 'Tarefa 2', '1', 'open', '0', NULL, '', '2019-05-07 12:00', '2019-05-09 12:00', NULL, '0', '2', NULL, '0', '0', '0', '0', '1', '0', '0', '0', '0', '2019-05-06 11:45:36', '3', '2', 'QDGIC4CWZP');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `description`, `start_date`, `due_date`, `completion_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `sucessors`, `scheduled_time`, `reference`) VALUES ('3', '1', 'Tarefa 3', '2', 'open', '0', NULL, '', '2019-05-15 12:00', '2019-07-12 12:00', NULL, '0', '2', NULL, '0', '0', '0', '0', '1', '0', '0', '0', '0', '2019-05-06 11:46:06', '4', '2', 'O6KTJJGOVB');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `description`, `start_date`, `due_date`, `completion_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `sucessors`, `scheduled_time`, `reference`) VALUES ('4', '1', 'Tarefa 4', '1', 'open', '0', NULL, '', '2019-05-17 12:00', '2019-08-23 17:05', NULL, '0', '2', NULL, '0', '0', '0', '0', '1', '0', '0', '0', '0', '2019-05-06 11:48:38', NULL, '4', 'EXUH5YKAEK');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `description`, `start_date`, `due_date`, `completion_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `sucessors`, `scheduled_time`, `reference`) VALUES ('5', '2', 'Tarefa 1', '1', 'open', '0', NULL, '', NULL, NULL, NULL, '0', '2', NULL, '0', '0', '0', '0', '2', '0', '0', '0', '0', '2019-05-06 12:41:42', '6', '3', 'PJFZLCS757');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `description`, `start_date`, `due_date`, `completion_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `sucessors`, `scheduled_time`, `reference`) VALUES ('6', '2', 'Tarefa 2', '1', 'open', '0', NULL, '', '2019-07-01 11:42', '2019-08-05 11:42', NULL, '0', '2', NULL, '0', '0', '0', '0', '2', '0', '0', '0', '0', '2019-05-06 12:41:42', '7', '2', 'QDGIC4CWZP');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `description`, `start_date`, `due_date`, `completion_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `sucessors`, `scheduled_time`, `reference`) VALUES ('7', '2', 'Tarefa 3', '2', 'open', '0', NULL, '', '2019-07-01 11:41', '2019-07-31 21:41', NULL, '0', '2', NULL, '0', '0', '0', '0', '2', '0', '0', '0', '0', '2019-05-06 12:41:42', '8', '2', 'O6KTJJGOVB');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `description`, `start_date`, `due_date`, `completion_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `sucessors`, `scheduled_time`, `reference`) VALUES ('8', '2', 'Tarefa 4', '1', 'open', '0', NULL, '', '2019-07-01 11:42', '2019-08-02 11:42', NULL, '0', '2', NULL, '0', '0', '0', '0', '2', '0', '0', '0', '0', '2019-05-06 12:41:42', NULL, '4', 'EXUH5YKAEK');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `description`, `start_date`, `due_date`, `completion_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `sucessors`, `scheduled_time`, `reference`) VALUES ('9', '2', 'Tarefa 1', '1', 'open', '0', NULL, '', '', '', NULL, '0', '2', NULL, '0', '0', '0', '0', '3', '0', '0', '0', '0', '2019-07-04 11:18:10', '11', '3', 'BDH6YVLTRF');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `description`, `start_date`, `due_date`, `completion_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `sucessors`, `scheduled_time`, `reference`) VALUES ('10', '2', 'Tarefa 2', '1', 'open', '0', NULL, '', '', '', NULL, '0', '2', NULL, '0', '0', '0', '0', '3', '0', '0', '0', '0', '2019-07-04 11:18:10', '11', '2', 'KLZLMIFWC0');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `description`, `start_date`, `due_date`, `completion_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `sucessors`, `scheduled_time`, `reference`) VALUES ('11', '2', 'Tarefa 3', '2', 'open', '0', NULL, '', '', '', NULL, '0', '2', NULL, '0', '0', '0', '0', '3', '0', '0', '0', '0', '2019-07-04 11:18:10', NULL, '2', 'DDWCDUQ6RK');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `description`, `start_date`, `due_date`, `completion_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `sucessors`, `scheduled_time`, `reference`) VALUES ('12', '2', 'Tarefa 4', '1', 'open', '0', NULL, '', NULL, NULL, NULL, '0', '2', NULL, '0', '0', '0', '0', '3', '0', '0', '0', '0', '2019-07-04 11:18:10', NULL, '4', 'XINVPCKT7I');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `description`, `start_date`, `due_date`, `completion_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `sucessors`, `scheduled_time`, `reference`) VALUES ('13', '2', 'Tarefa 1', '1', 'open', '0', NULL, '', NULL, NULL, NULL, '0', '2', NULL, '0', '0', '0', '0', '4', '0', '0', '0', '0', '2019-07-04 11:26:50', '6', '3', 'A4N8NKXC3H');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `description`, `start_date`, `due_date`, `completion_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `sucessors`, `scheduled_time`, `reference`) VALUES ('14', '2', 'Tarefa 2', '1', 'open', '0', NULL, '', NULL, NULL, NULL, '0', '2', NULL, '0', '0', '0', '0', '4', '0', '0', '0', '0', '2019-07-04 11:26:50', '7', '2', '2HARWFNPGL');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `description`, `start_date`, `due_date`, `completion_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `sucessors`, `scheduled_time`, `reference`) VALUES ('15', '2', 'Tarefa 3', '2', 'open', '0', NULL, '', NULL, NULL, NULL, '0', '2', NULL, '0', '0', '0', '0', '4', '0', '0', '0', '0', '2019-07-04 11:26:50', '8', '2', 'BF0ARBCMG3');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `description`, `start_date`, `due_date`, `completion_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `sucessors`, `scheduled_time`, `reference`) VALUES ('16', '2', 'Tarefa 4', '1', 'open', '0', NULL, '', NULL, NULL, NULL, '0', '2', NULL, '0', '0', '0', '0', '4', '0', '0', '0', '0', '2019-07-04 11:26:50', NULL, '4', 'KF1SS2GNNF');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `description`, `start_date`, `due_date`, `completion_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `sucessors`, `scheduled_time`, `reference`) VALUES ('17', '2', 'Tarefa 1', '1', 'open', '0', NULL, '', NULL, NULL, NULL, '0', '2', NULL, '0', '0', '0', '0', '5', '0', '0', '0', '0', '2019-07-04 11:31:53', '6', '3', 'N6ARAEZAFK');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `description`, `start_date`, `due_date`, `completion_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `sucessors`, `scheduled_time`, `reference`) VALUES ('18', '2', 'Tarefa 2', '1', 'open', '0', NULL, '', NULL, NULL, NULL, '0', '2', NULL, '0', '0', '0', '0', '5', '0', '0', '0', '0', '2019-07-04 11:31:53', '7', '2', 'TQU2DSWSPI');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `description`, `start_date`, `due_date`, `completion_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `sucessors`, `scheduled_time`, `reference`) VALUES ('19', '2', 'Tarefa 3', '2', 'open', '0', NULL, '', NULL, NULL, NULL, '0', '2', NULL, '0', '0', '0', '0', '5', '0', '0', '0', '0', '2019-07-04 11:31:53', '8', '2', 'VIM45OYH3M');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `description`, `start_date`, `due_date`, `completion_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `sucessors`, `scheduled_time`, `reference`) VALUES ('20', '2', 'Tarefa 4', '1', 'open', '0', NULL, '', NULL, NULL, NULL, '0', '2', NULL, '0', '0', '0', '0', '5', '0', '0', '0', '0', '2019-07-04 11:31:53', NULL, '4', '0EUCIJDZYQ');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `description`, `start_date`, `due_date`, `completion_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `sucessors`, `scheduled_time`, `reference`) VALUES ('21', '2', 'Tarefa 1', '1', 'open', '0', NULL, '', NULL, NULL, NULL, '0', '2', NULL, '0', '0', '0', '0', '6', '0', '0', '0', '0', '2019-07-08 15:43:51', '6', '3', 'XSPL4PKM1Q');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `description`, `start_date`, `due_date`, `completion_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `sucessors`, `scheduled_time`, `reference`) VALUES ('22', '2', 'Tarefa 2', '1', 'open', '0', NULL, '', NULL, NULL, NULL, '0', '2', NULL, '0', '0', '0', '0', '6', '0', '0', '0', '0', '2019-07-08 15:43:51', '7', '2', '00SWKEGAFX');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `description`, `start_date`, `due_date`, `completion_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `sucessors`, `scheduled_time`, `reference`) VALUES ('23', '2', 'Tarefa 3', '2', 'open', '0', NULL, '', NULL, NULL, NULL, '0', '2', NULL, '0', '0', '0', '0', '6', '0', '0', '0', '0', '2019-07-08 15:43:51', '8', '2', 'L8ZFHAH28L');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `description`, `start_date`, `due_date`, `completion_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `sucessors`, `scheduled_time`, `reference`) VALUES ('24', '2', 'Tarefa 4', '1', 'open', '0', NULL, '', NULL, NULL, NULL, '0', '2', NULL, '0', '0', '0', '0', '6', '0', '0', '0', '0', '2019-07-08 15:43:51', NULL, '4', 'BSCZGDEFXS');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `description`, `start_date`, `due_date`, `completion_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `sucessors`, `scheduled_time`, `reference`) VALUES ('25', '2', 'Tarefa 1', '1', 'open', '0', NULL, '', NULL, NULL, NULL, '0', '2', NULL, '0', '0', '0', '0', '7', '0', '0', '0', '0', '2019-07-08 15:49:02', '6', '3', 'U2HKLLLHSI');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `description`, `start_date`, `due_date`, `completion_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `sucessors`, `scheduled_time`, `reference`) VALUES ('26', '2', 'Tarefa 2', '1', 'open', '0', NULL, '', NULL, NULL, NULL, '0', '2', NULL, '0', '0', '0', '0', '7', '0', '0', '0', '0', '2019-07-08 15:49:02', '7', '2', 'DNZD6XWQ32');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `description`, `start_date`, `due_date`, `completion_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `sucessors`, `scheduled_time`, `reference`) VALUES ('27', '2', 'Tarefa 3', '2', 'open', '0', NULL, '', NULL, NULL, NULL, '0', '2', NULL, '0', '0', '0', '0', '7', '0', '0', '0', '0', '2019-07-08 15:49:02', '8', '2', 'YYGXGQ1JGT');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `description`, `start_date`, `due_date`, `completion_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `sucessors`, `scheduled_time`, `reference`) VALUES ('28', '2', 'Tarefa 4', '1', 'open', '0', NULL, '', NULL, NULL, NULL, '0', '2', NULL, '0', '0', '0', '0', '7', '0', '0', '0', '0', '2019-07-08 15:49:02', NULL, '4', 'SUFGBGFHTW');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `description`, `start_date`, `due_date`, `completion_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `sucessors`, `scheduled_time`, `reference`) VALUES ('29', '2', 'Tarefa 1', '1', 'open', '0', NULL, '', NULL, NULL, NULL, '0', '2', NULL, '0', '0', '0', '0', '8', '0', '0', '0', '0', '2019-07-08 15:50:30', '6', '3', 'LOTKM8K2NE');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `description`, `start_date`, `due_date`, `completion_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `sucessors`, `scheduled_time`, `reference`) VALUES ('30', '2', 'Tarefa 2', '1', 'open', '0', NULL, '', NULL, NULL, NULL, '0', '2', NULL, '0', '0', '0', '0', '8', '0', '0', '0', '0', '2019-07-08 15:50:30', '7', '2', 'LKAYPE4ZIL');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `description`, `start_date`, `due_date`, `completion_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `sucessors`, `scheduled_time`, `reference`) VALUES ('31', '2', 'Tarefa 3', '2', 'open', '0', NULL, '', NULL, NULL, NULL, '0', '2', NULL, '0', '0', '0', '0', '8', '0', '0', '0', '0', '2019-07-08 15:50:30', '8', '2', 'X6V7SLREIZ');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `description`, `start_date`, `due_date`, `completion_date`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `sucessors`, `scheduled_time`, `reference`) VALUES ('32', '2', 'Tarefa 4', '1', 'open', '0', NULL, '', NULL, NULL, NULL, '0', '2', NULL, '0', '0', '0', '0', '8', '0', '0', '0', '0', '2019-07-08 15:50:30', NULL, '4', 'SVA6VKS2BT');


#
# TABLE STRUCTURE FOR: project_has_timesheets
#

DROP TABLE IF EXISTS project_has_timesheets;

CREATE TABLE `project_has_timesheets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `time` varchar(250) DEFAULT '0',
  `task_id` int(11) DEFAULT '0',
  `client_id` int(11) DEFAULT '0',
  `start` varchar(250) DEFAULT '0',
  `end` varchar(250) DEFAULT '0',
  `invoice_id` int(11) DEFAULT '0',
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: project_has_workers
#

DROP TABLE IF EXISTS project_has_workers;

CREATE TABLE `project_has_workers` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `project_id` int(10) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('1', '1', '1');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('2', '2', '1');


#
# TABLE STRUCTURE FOR: projects
#

DROP TABLE IF EXISTS projects;

CREATE TABLE `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` int(11) DEFAULT '0',
  `name` varchar(65) DEFAULT NULL,
  `description` text,
  `start` varchar(20) DEFAULT NULL,
  `end` varchar(20) DEFAULT NULL,
  `progress` decimal(3,0) DEFAULT NULL,
  `phases` varchar(150) DEFAULT NULL,
  `tracking` int(11) DEFAULT '0',
  `time_spent` int(11) DEFAULT '0',
  `datetime` int(11) DEFAULT '0',
  `sticky` enum('1','0') DEFAULT '0',
  `color` varchar(100) DEFAULT '#5071ab',
  `company_id` int(11) DEFAULT '0',
  `note` longtext,
  `progress_calc` tinyint(4) DEFAULT '0',
  `hide_tasks` int(1) DEFAULT '0',
  `enable_client_tasks` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO projects (`id`, `reference`, `name`, `description`, `start`, `end`, `progress`, `phases`, `tracking`, `time_spent`, `datetime`, `sticky`, `color`, `company_id`, `note`, `progress_calc`, `hide_tasks`, `enable_client_tasks`) VALUES ('1', '1', 'Projeto 1', '', '2019-04-01 12:00', '2019-07-31 12:00', '0', NULL, '0', '0', '1557153832', '0', '#eb3135', '3', NULL, '1', '0', '0');
INSERT INTO projects (`id`, `reference`, `name`, `description`, `start`, `end`, `progress`, `phases`, `tracking`, `time_spent`, `datetime`, `sticky`, `color`, `company_id`, `note`, `progress_calc`, `hide_tasks`, `enable_client_tasks`) VALUES ('2', '2', 'Projeto 2', '', '2019-04-01 12:00', '2019-07-31 12:00', '0', NULL, '0', '0', '1557157302', '0', '#ce31eb', '3', NULL, '1', '0', '0');


#
# TABLE STRUCTURE FOR: pw_reset
#

DROP TABLE IF EXISTS pw_reset;

CREATE TABLE `pw_reset` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `email` varchar(250) DEFAULT NULL,
  `timestamp` varchar(250) DEFAULT NULL,
  `token` varchar(250) DEFAULT NULL,
  `user` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO pw_reset (`id`, `email`, `timestamp`, `token`, `user`) VALUES ('1', 'zenit.cliente3@ownergy.com.br', '1544556167', 'b0639bc1d3cd121cb8f038875487e3dc61419c0684a825d320d817185fa2f5b7', '0');


#
# TABLE STRUCTURE FOR: queues
#

DROP TABLE IF EXISTS queues;

CREATE TABLE `queues` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL,
  `inactive` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO queues (`id`, `name`, `description`, `inactive`) VALUES ('1', 'Administrativo', 'Tickets ligados à área administrativa', '0');
INSERT INTO queues (`id`, `name`, `description`, `inactive`) VALUES ('2', 'Comercial', 'Tickets ligados à área comercial', '0');
INSERT INTO queues (`id`, `name`, `description`, `inactive`) VALUES ('3', 'Engenharia', 'Tickets ligados à área de engenharia', '0');
INSERT INTO queues (`id`, `name`, `description`, `inactive`) VALUES ('4', 'Tecnologia', 'Tickets ligados à área de tecnologia', '0');


#
# TABLE STRUCTURE FOR: reminders
#

DROP TABLE IF EXISTS reminders;

CREATE TABLE `reminders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(250) DEFAULT NULL,
  `source_id` bigint(20) DEFAULT '0',
  `title` varchar(250) DEFAULT NULL,
  `body` text,
  `email_notification` int(1) DEFAULT '0',
  `done` int(1) DEFAULT '0',
  `datetime` varchar(50) DEFAULT NULL,
  `sent_at` varchar(50) DEFAULT '0',
  `user_id` int(20) DEFAULT '0',
  `push_notification` tinyint(1) NOT NULL DEFAULT '0',
  `push_sent_at` varchar(50) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO reminders (`id`, `module`, `source_id`, `title`, `body`, `email_notification`, `done`, `datetime`, `sent_at`, `user_id`, `push_notification`, `push_sent_at`) VALUES ('1', 'lead', '8', 'Teste de alarme', '<p>Teste</p>', '0', '0', '2019-04-15 09:30:00 -03', '0', '1', '1', '0');


#
# TABLE STRUCTURE FOR: tags
#

DROP TABLE IF EXISTS tags;

CREATE TABLE `tags` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO tags (`id`, `name`) VALUES ('1', 'Rural');
INSERT INTO tags (`id`, `name`) VALUES ('2', 'Urbano');
INSERT INTO tags (`id`, `name`) VALUES ('3', 'Comercial');
INSERT INTO tags (`id`, `name`) VALUES ('4', 'Industrial');


#
# TABLE STRUCTURE FOR: task_has_comments
#

DROP TABLE IF EXISTS task_has_comments;

CREATE TABLE `task_has_comments` (
  `id` bigint(255) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `client_id` int(11) DEFAULT NULL,
  `message` text,
  `datetime` varchar(20) DEFAULT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `task_id` bigint(20) DEFAULT NULL,
  `attachment_link` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: templates
#

DROP TABLE IF EXISTS templates;

CREATE TABLE `templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(250) NOT NULL,
  `name` varchar(250) NOT NULL,
  `text` text,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ticket_has_articles
#

DROP TABLE IF EXISTS ticket_has_articles;

CREATE TABLE `ticket_has_articles` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) DEFAULT '0',
  `from` varchar(250) NOT NULL,
  `reply_to` varchar(250) DEFAULT NULL,
  `to` varchar(250) DEFAULT NULL,
  `cc` varchar(250) DEFAULT NULL,
  `subject` varchar(250) DEFAULT NULL,
  `message` text,
  `datetime` varchar(250) DEFAULT NULL,
  `internal` int(10) DEFAULT '1',
  `user_id` bigint(20) DEFAULT '0',
  `note` int(1) DEFAULT '0',
  `raw` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO ticket_has_articles (`id`, `ticket_id`, `from`, `reply_to`, `to`, `cc`, `subject`, `message`, `datetime`, `internal`, `user_id`, `note`, `raw`) VALUES ('1', '1', 'Thiago Pires - thiago.pires@ownergy.com.br', 'thiago.pires@ownergy.com.br', NULL, NULL, '', '<p>Nota teste em ticket</p>', '1545075924', '1', '1', '1', NULL);
INSERT INTO ticket_has_articles (`id`, `ticket_id`, `from`, `reply_to`, `to`, `cc`, `subject`, `message`, `datetime`, `internal`, `user_id`, `note`, `raw`) VALUES ('2', '1', 'Thiago Pires - thiago.pires@ownergy.com.br', 'thiago.pires@ownergy.com.br', '2', NULL, 'Ticket atribuído', 'Teste de comentário na atribuição', '1545076031', '0', '0', '0', NULL);
INSERT INTO ticket_has_articles (`id`, `ticket_id`, `from`, `reply_to`, `to`, `cc`, `subject`, `message`, `datetime`, `internal`, `user_id`, `note`, `raw`) VALUES ('3', '1', 'Thiago Pires - thiago.pires@ownergy.com.br', 'thiago.pires@ownergy.com.br', '2', NULL, 'Ticket atribuído', '<p>teste</p>', '1545076250', '0', '0', '0', NULL);


#
# TABLE STRUCTURE FOR: ticket_has_attachments
#

DROP TABLE IF EXISTS ticket_has_attachments;

CREATE TABLE `ticket_has_attachments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ticket_id` bigint(20) DEFAULT NULL,
  `filename` varchar(250) DEFAULT NULL,
  `savename` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tickets
#

DROP TABLE IF EXISTS tickets;

CREATE TABLE `tickets` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `from` varchar(250) DEFAULT NULL,
  `reference` varchar(250) DEFAULT NULL,
  `type_id` smallint(6) DEFAULT '1',
  `lock` smallint(6) DEFAULT NULL,
  `subject` varchar(250) DEFAULT NULL,
  `text` text,
  `status` varchar(50) DEFAULT NULL,
  `client_id` int(11) DEFAULT '0',
  `company_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `escalation_time` int(11) DEFAULT '0',
  `priority` varchar(50) DEFAULT NULL,
  `created` int(11) DEFAULT '0',
  `queue_id` int(11) DEFAULT '0',
  `updated` tinyint(4) DEFAULT '0',
  `project_id` bigint(20) DEFAULT '0',
  `raw` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO tickets (`id`, `from`, `reference`, `type_id`, `lock`, `subject`, `text`, `status`, `client_id`, `company_id`, `user_id`, `escalation_time`, `priority`, `created`, `queue_id`, `updated`, `project_id`, `raw`) VALUES ('1', 'Thiago Pires - thiago.pires@ownergy.com.br', '5000', '3', NULL, 'Ticket teste 1', '<p>Ticket de teste</p>', 'open', '2', '2', '1', '0', NULL, '1545073914', '4', '0', '2', NULL);


#
# TABLE STRUCTURE FOR: types
#

DROP TABLE IF EXISTS types;

CREATE TABLE `types` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL,
  `inactive` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO types (`id`, `name`, `description`, `inactive`) VALUES ('1', 'Prevenção', 'Tickets de prevenção', '0');
INSERT INTO types (`id`, `name`, `description`, `inactive`) VALUES ('2', 'Remediação', 'Tickets de remediação', '0');
INSERT INTO types (`id`, `name`, `description`, `inactive`) VALUES ('3', 'Solicitação', 'Tickets de solicitações', '0');
INSERT INTO types (`id`, `name`, `description`, `inactive`) VALUES ('4', 'Investigação', 'Tickets de investigação', '0');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS users;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(45) DEFAULT NULL,
  `firstname` varchar(120) DEFAULT NULL,
  `lastname` varchar(120) DEFAULT NULL,
  `hashed_password` varchar(128) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `status` enum('active','inactive','deleted') DEFAULT NULL,
  `admin` enum('0','1') DEFAULT '0',
  `created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `userpic` varchar(250) DEFAULT 'no-pic.png',
  `title` varchar(150) DEFAULT NULL,
  `access` varchar(150) NOT NULL DEFAULT '1,2',
  `last_active` varchar(50) DEFAULT NULL,
  `last_login` varchar(50) DEFAULT NULL,
  `queue` bigint(20) DEFAULT '0',
  `token` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `signature` text,
  `push_active` enum('0','1') NOT NULL DEFAULT '1' COMMENT 'Permissão para receber pushes',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO users (`id`, `username`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `last_active`, `last_login`, `queue`, `token`, `language`, `signature`, `push_active`) VALUES ('1', 'thiago.pires', 'Thiago', 'Pires', '3048405e5d403b655b452b316e2566325d4d4d625c565d4e7654626358572743b1dd243ebe064dd6095e80fbfb32b0a767c20c8db0b334fd189f5e8de98a0231', 'thiago.pires@ownergy.com.br', 'active', '1', '2018-11-26 09:41:06', '6a7db41b635e4c43bfd61f79ef7c78ec.jpeg', 'Analista de Inovação', '1,2,3,4,108,34,20,105,9,10,11', '1569843955', '1569843946', '4', '8dacf92301e47aa845f807057cd04abc', NULL, 'Thiago Pires', '1');
INSERT INTO users (`id`, `username`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `last_active`, `last_login`, `queue`, `token`, `language`, `signature`, `push_active`) VALUES ('2', 'jorge.felipe', 'Jorge Felipe', 'Barbosa Mota', '564725266167497541494a504226582d7c5e385c7a7d4b48215e646a78524b5d5ffc49f92487e081841587d8121b475125d1206adee14c8bcd8ddc0a21d9cdbd', 'thiago@solarbid.com.br', 'active', '0', '2018-12-10 16:06:35', 'd3b0ce907e249e12b6abcb5dfa6be054.png', 'Gerente de Projetos', '1,2,3,4,108,34,20,105,10,11', '1560794857', '1560794852', '3', NULL, NULL, 'Jorge Felipe B. Mota', '1');


